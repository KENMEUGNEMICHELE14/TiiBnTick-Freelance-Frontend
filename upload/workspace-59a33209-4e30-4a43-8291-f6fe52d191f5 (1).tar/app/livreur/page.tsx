'use client'

import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { useToast } from '@/hooks/use-toast'
import {
  Package,
  MapPin,
  Clock,
  DollarSign,
  Star,
  CheckCircle2,
  Navigation,
  Bell,
  User,
  Settings,
  LogOut,
  Menu,
  X,
  Phone,
  Map as MapIcon,
  AlertCircle,
  TrendingUp,
  CreditCard,
  Calendar,
  LayoutDashboard,
  Megaphone,
  Truck,
  Home,
  Crown,
  Award,
  Target,
  Zap,
  BarChart3,
  ArrowUpRight,
  Shield,
} from 'lucide-react'
import { withAuth } from '@/components/hoc/withAuth'
import { useAuth } from '@/context/AuthContext'
import { useRouter } from 'next/navigation'
import { acceptDelivery as acceptDeliveryService } from '@/services/deliveryService'
import dynamic from 'next/dynamic'
import { getRoute } from '@/services/routing'
import { useEffect, useCallback } from 'react'
import {
  getPublishedAnnouncements,
  getDeliveryPersonSubscriptions,
  AnnouncementResponseDTO
} from '@/services/announcementService'

const MapLeaflet = dynamic(() => import('@/components/MapLeaflet'), {
  ssr: false,
  loading: () => <div className="w-full h-64 bg-gray-100 animate-pulse rounded-xl" />
});

import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
  DialogClose,
} from '@/components/ui/dialog'
import { ThumbsUp, MessageCircle, Mail, ImageIcon, Heart, History, ClipboardList, UserCircle } from 'lucide-react'
import apiClient from '@/lib/axios'
import { cn } from '@/lib/utils'

// Google Wallet-style icon
function GoogleWalletIcon({ className = 'w-5 h-5' }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
      {/* Back card - orange */}
      <rect x="4" y="10" width="28" height="28" rx="5" fill="#F97316" />
      {/* Front card - with orange/white stripes */}
      <rect x="16" y="6" width="28" height="28" rx="5" fill="#fff" stroke="#FDBA74" strokeWidth="1" />
      {/* Colored stripes on front card */}
      <rect x="16" y="6" width="28" height="7" rx="5" fill="#FFF7ED" />
      <rect x="16" y="6" width="28" height="7" rx="5" fill="url(#wallet-gradient-top)" />
      <rect x="16" y="27" width="28" height="7" rx="0" fill="#FED7AA" />
      <rect x="16" y="27" width="28" height="7" rx="5" fill="url(#wallet-gradient-bottom)" />
      {/* W letter */}
      <path d="M26 20L23 26L20 20H18L22.5 28L21 31H23L29 20H26Z" fill="#F97316" />
      <path d="M32 20L29 26L26 20H24L28.5 28L27 31H29L35 20H32Z" fill="#F97316" opacity="0.7" />
      <defs>
        <linearGradient id="wallet-gradient-top" x1="16" y1="6" x2="44" y2="13">
          <stop offset="0" stopColor="#FDBA74" />
          <stop offset="0.5" stopColor="#FFFFFF" />
          <stop offset="1" stopColor="#FED7AA" />
        </linearGradient>
        <linearGradient id="wallet-gradient-bottom" x1="16" y1="27" x2="44" y2="34">
          <stop offset="0" stopColor="#FDBA74" />
          <stop offset="1" stopColor="#F97316" />
        </linearGradient>
      </defs>
    </svg>
  )
}

// Deterministic number formatter (avoids hydration mismatch between server and client)
function fmt(n: number | undefined): string {
  if (n == null) return '0'
  return n.toString().replace(/\B(?=(\d{3})+(?!\d))/g, '\u00A0')
}

export function LivreurDashboard() {
  const router = useRouter()
  const { toast } = useToast()
  const { user, logout } = useAuth()
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const [activeTab, setActiveTab] = useState('accueil')

  // Livreur info from context
  const livreurInfo = {
    firstName: user?.firstName || 'Livreur',
    lastName: user?.lastName || '',
    rating: user?.rating || 4.8,
    totalDeliveries: user?.totalDeliveries || 156,
    totalEarnings: 245000,
    phone: user?.phone || '+225 07 00 00 00 00'
  }


  // Available announcements from API
  const [availableDeliveries, setAvailableDeliveries] = useState<AnnouncementResponseDTO[]>([])
  const [availableLoading, setAvailableLoading] = useState(false)

  // Active deliveries (subscribed announcements) from API
  const [activeDeliveries, setActiveDeliveries] = useState<AnnouncementResponseDTO[]>([])
  const [activeLoading, setActiveLoading] = useState(false)

  const [selectedDelivery, setSelectedDelivery] = useState<any>(null)
  const [detailsOpen, setDetailsOpen] = useState(false)
  const [activeRoute, setActiveRoute] = useState<any>(null)
  const [pendingSubscriptions, setPendingSubscriptions] = useState<Set<string>>(new Set())
  const [subscribedIds, setSubscribedIds] = useState<Set<string>>(() => {
    // Restore from localStorage on mount
    if (typeof window !== 'undefined') {
      try {
        const saved = localStorage.getItem('livreur_subscribed_ids');
        if (saved) return new Set(JSON.parse(saved));
      } catch (e) { /* ignore */ }
    }
    return new Set();
  })

  // Fetch published announcements
  const fetchAvailableDeliveries = useCallback(async () => {
    setAvailableLoading(true)
    try {
      const data = await getPublishedAnnouncements()
      // Only show PUBLISHED announcements (not ASSIGNED)
      setAvailableDeliveries(data.filter(a => a.status === 'PUBLISHED'))
    } catch (error) {
      console.error('Error fetching announcements:', error)
    } finally {
      setAvailableLoading(false)
    }
  }, [])

  // Stable user ID for dependency (avoids re-fetching on every user object change)
  const deliveryPersonIdRef = user?.deliveryPersonId || user?.id

  // Fetch delivery person's subscriptions (active deliveries)
  const fetchMyDeliveries = useCallback(async () => {
    if (!deliveryPersonIdRef) return
    setActiveLoading(true)
    try {
      const data = await getDeliveryPersonSubscriptions(deliveryPersonIdRef)
      setActiveDeliveries(data)
      // Merge API subscription IDs into existing set (don't overwrite locally-added IDs)
      const apiIds = data.map(a => a.id)
      setSubscribedIds(prev => {
        const merged = new Set(prev)
        apiIds.forEach(id => merged.add(id))
        // Persist to localStorage
        try { localStorage.setItem('livreur_subscribed_ids', JSON.stringify([...merged])); } catch (e) { /* ignore */ }
        return merged
      })
    } catch (error) {
      console.error('Error fetching my deliveries:', error)
    } finally {
      setActiveLoading(false)
    }
  }, [deliveryPersonIdRef])

  useEffect(() => {
    fetchAvailableDeliveries()
    fetchMyDeliveries()
  }, [fetchAvailableDeliveries, fetchMyDeliveries])

  // Real-time notifications via SSE
  useEffect(() => {
    if (!user?.id) return;

    // Use relative path to go through Gateway and add token for authentication
    const token = localStorage.getItem('token');
    const eventSource = new EventSource(`/api/notifications/stream/${user.id}${token ? `?token=${token}` : ''}`);

    eventSource.onmessage = (event) => {
      try {
        if (!event.data) return;
        const matchingEvent = JSON.parse(event.data);
        if (!matchingEvent.announcementId) return;
        console.info('Received real-time matching notification:', matchingEvent);

        // Fetch announcement details to add to available deliveries
        apiClient.get(`/api/announcements/${matchingEvent.announcementId}`)
          .then(res => {
            const announcement = res.data;
            setAvailableDeliveries(prev => {
              if (prev.find(d => d.id === announcement.id)) return prev;
              return [announcement as AnnouncementResponseDTO, ...prev];
            });

            toast({
              title: "Nouvelle course disponible !",
              description: announcement.title || "Une nouvelle course correspond à votre position.",
            });
          });
      } catch (err) {
        console.error('Error parsing SSE event:', err);
      }
    };

    eventSource.onerror = () => {
      eventSource.close();
    };

    return () => {
      eventSource.close();
    };
  }, [user?.id]);

  useEffect(() => {
    if (
      selectedDelivery?.pickupAddress?.latitude &&
      selectedDelivery?.pickupAddress?.longitude &&
      selectedDelivery?.deliveryAddress?.latitude &&
      selectedDelivery?.deliveryAddress?.longitude
    ) {
      const fetchRoute = async () => {
        try {
          const route = await getRoute(
            selectedDelivery.pickupAddress.latitude,
            selectedDelivery.pickupAddress.longitude,
            selectedDelivery.deliveryAddress.latitude,
            selectedDelivery.deliveryAddress.longitude,
            selectedDelivery.transportMethod === 'bike' ? 'bike' : 'driving'
          );
          setActiveRoute(route);
        } catch (e) {
          console.error("Failed to fetch route", e);
          setActiveRoute(null);
        }
      };
      fetchRoute();
    } else {
      setActiveRoute(null);
    }
  }, [selectedDelivery]);


  // availability toggle removed per UI request

  const handleAcceptDelivery = async (deliveryId: string) => {
    if (!user?.id) {
      toast({
        title: "Erreur",
        description: "Vous devez être connecté pour souscrire à une annonce.",
        variant: "destructive"
      });
      return;
    }

    setPendingSubscriptions(prev => {
      const next = new Set(prev);
      next.add(deliveryId);
      return next;
    });

    try {
      const response = await apiClient.post(`/api/announcements/${deliveryId}/subscribe`, {
        deliveryPersonId: user.deliveryPersonId || user.id
      });

      if (response.status === 200 || response.status === 201 || response.status === 202) {
        setSubscribedIds(prev => {
          const next = new Set(prev);
          next.add(deliveryId);
          // Persist to localStorage
          try { localStorage.setItem('livreur_subscribed_ids', JSON.stringify([...next])); } catch (e) { /* ignore */ }
          return next;
        });
        // Clean up pending state
        setPendingSubscriptions(prev => {
          const next = new Set(prev);
          next.delete(deliveryId);
          return next;
        });
        toast({
          title: "Demande envoyée",
          description: "Votre demande de souscription est en cours de traitement.",
        })
      } else {
        setPendingSubscriptions(prev => {
          const next = new Set(prev);
          next.delete(deliveryId);
          return next;
        });
        toast({
          title: "Erreur",
          description: "Impossible d'envoyer la demande de souscription.",
          variant: "destructive",
        })
      }
    } catch (error) {
      setPendingSubscriptions(prev => {
        const next = new Set(prev);
        next.delete(deliveryId);
        return next;
      });
      toast({
        title: "Erreur",
        description: "Une erreur réseau est survenue.",
        variant: "destructive",
      })
    }
  }

  const handleStartDelivery = (deliveryId: string) => {
    // TODO: Implémenter la logique de démarrage de livraison
    console.log('Démarrage de la livraison:', deliveryId)
  }

  const getUrgencyBadge = (urgency: string) => {
    switch (urgency) {
      case 'urgent':
      case 'high':
        return <Badge variant="destructive" className="bg-red-500">Urgent</Badge>
      case 'normal':
        return <Badge variant="outline" className="border-blue-500 text-blue-700">Normal</Badge>
      default:
        return <Badge variant="outline">Standard</Badge>
    }
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'pickup':
        return <Badge variant="outline" className="bg-orange-100 text-orange-700 border-orange-300"><MapPin className="w-3 h-3 mr-1" /> En attente retrait</Badge>
      case 'delivery':
        return <Badge variant="outline" className="bg-blue-100 text-blue-700 border-blue-300"><Navigation className="w-3 h-3 mr-1" /> En livraison</Badge>
      case 'completed':
        return <Badge variant="outline" className="bg-green-100 text-green-700 border-green-300"><CheckCircle2 className="w-3 h-3 mr-1" /> Livré</Badge>
      default:
        return <Badge variant="outline">{status}</Badge>
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-white border-b shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 bg-gradient-to-br from-orange-500 to-amber-500 rounded-xl flex items-center justify-center">
                <Package className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold">
                  TiiB<span className="text-orange-500">n</span>Tick
                </h1>
                <p className="text-xs text-gray-500">Espace Livreur</p>
              </div>
            </div>

            {/* Desktop Navigation */}
            <nav className="hidden md:flex items-center gap-4">
              {/* Notification Bell */}
              <Button variant="ghost" size="icon" className="relative opacity-50 cursor-not-allowed" disabled>
                <Bell className="w-5 h-5" />
              </Button>

              {/* Profile Menu */}
              <div className="flex items-center gap-2 px-3 py-2 bg-orange-50 rounded-lg border border-orange-200">
                <div className="w-8 h-8 bg-gradient-to-br from-orange-500 to-amber-500 rounded-full flex items-center justify-center">
                  <User className="w-4 h-4 text-white" />
                </div>
                <div className="hidden lg:block">
                  <p className="text-sm font-semibold text-gray-900">{livreurInfo.lastName} {livreurInfo.firstName}</p>
                  <div className="flex items-center gap-1">
                    <Star className="w-3 h-3 text-yellow-500 fill-current" />
                    <span className="text-xs text-gray-600">{livreurInfo.rating}</span>
                  </div>
                </div>
              </div>

              <Button variant="ghost" size="icon" className="opacity-50 cursor-not-allowed" disabled>
                <Settings className="w-5 h-5" />
              </Button>

              <Button variant="ghost" size="icon" className="text-red-600" onClick={logout}>
                <LogOut className="w-5 h-5" />
              </Button>
            </nav>

            {/* Mobile Menu */}
            <div className="md:hidden flex items-center gap-2">
              <Button variant="ghost" size="icon" className="relative opacity-50 cursor-not-allowed" disabled>
                <Bell className="w-5 h-5" />
              </Button>

              <Button
                variant="ghost"
                size="icon"
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              >
                {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </Button>
            </div>
          </div>

          {/* Mobile Menu Dropdown */}
          {mobileMenuOpen && (
            <nav className="md:hidden border-t bg-white py-4 space-y-1">
              {/* User profile card */}
              <div className="flex items-center gap-3 px-4 py-3 mb-2">
                <div className="w-10 h-10 bg-gradient-to-br from-orange-500 to-amber-500 rounded-full flex items-center justify-center">
                  <User className="w-5 h-5 text-white" />
                </div>
                <div className="flex-1">
                  <p className="text-sm font-bold text-gray-900">{livreurInfo.lastName} {livreurInfo.firstName}</p>
                  <div className="flex items-center gap-1">
                    <Star className="w-3 h-3 text-yellow-500 fill-current" />
                    <span className="text-xs text-gray-600">{livreurInfo.rating}</span>
                  </div>
                </div>
                <Badge className="bg-green-100 text-green-700 border-green-300 text-[10px]">En ligne</Badge>
              </div>

              <div className="h-px bg-gray-100 mx-2" />

              {/* Navigation items */}
              <Button
                variant="ghost"
                className={cn(
                  'w-full justify-start gap-3 rounded-lg',
                  activeTab === 'accueil' ? 'bg-orange-50 text-orange-600 font-semibold' : 'text-gray-700'
                )}
                onClick={() => { setActiveTab('accueil'); setMobileMenuOpen(false); }}
              >
                <LayoutDashboard className="w-5 h-5" />
                Dashboard
              </Button>

              <Button
                variant="ghost"
                className={cn(
                  'w-full justify-start gap-3 rounded-lg',
                  activeTab === 'annonces' ? 'bg-orange-50 text-orange-600 font-semibold' : 'text-gray-700'
                )}
                onClick={() => { setActiveTab('annonces'); setMobileMenuOpen(false); }}
              >
                <Megaphone className="w-5 h-5" />
                Annonces
              </Button>

              <Button
                variant="ghost"
                className={cn(
                  'w-full justify-start gap-3 rounded-lg',
                  activeTab === 'livraisons' ? 'bg-orange-50 text-orange-600 font-semibold' : 'text-gray-700'
                )}
                onClick={() => { setActiveTab('livraisons'); setMobileMenuOpen(false); }}
              >
                <Truck className="w-5 h-5" />
                Livraisons
              </Button>

              <div className="h-px bg-gray-100 mx-2" />

              <Button
                variant="ghost"
                className="w-full justify-start gap-3 rounded-lg text-gray-700"
                onClick={() => { router.push('/livreur/historique'); setMobileMenuOpen(false); }}
              >
                <History className="w-5 h-5" />
                Historique
              </Button>

              <Button
                variant="ghost"
                className="w-full justify-start gap-3 rounded-lg text-gray-700"
                onClick={() => { router.push('/livreur/profil'); setMobileMenuOpen(false); }}
              >
                <UserCircle className="w-5 h-5" />
                Mon profil
              </Button>

              <Button
                variant="ghost"
                className="w-full justify-start gap-3 rounded-lg text-gray-700 opacity-50 cursor-not-allowed"
                disabled
              >
                <Settings className="w-5 h-5" />
                Paramètres
              </Button>

              <div className="h-px bg-gray-100 mx-2" />

              <Button
                variant="ghost"
                className="w-full justify-start gap-3 rounded-lg text-red-600 hover:bg-red-50"
                onClick={logout}
              >
                <LogOut className="w-5 h-5" />
                Déconnexion
              </Button>
            </nav>
          )}
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 p-4 sm:p-6 lg:p-8">
        <div className="max-w-7xl mx-auto space-y-6">
          {activeTab === 'accueil' && (
            <div className="space-y-6">
              {/* Welcome Section */}
              <div className="mb-2">
                <h2 className="text-2xl md:text-3xl font-bold">
                  Bienvenue, <span className="text-orange-600">{livreurInfo.lastName} {livreurInfo.firstName}</span>
                </h2>
                <p className="text-sm text-gray-500 mt-1">Voici un aperçu de votre activité</p>
                <Button
                  className="mt-3 bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-600 hover:to-amber-600 text-white"
                  size="sm"
                  onClick={() => router.push('/livreur/profil')}
                >
                  <User className="w-4 h-4 mr-2" />
                  Mettre à jour votre profil
                </Button>
              </div>

              {/* Stats Cards */}
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4">
                <Card className="hover:shadow-md transition-shadow flex flex-col">
                  <CardHeader className="pb-3 px-4 py-3">
                    <CardDescription className="text-[10px] md:text-xs text-black">En cours</CardDescription>
                    <CardTitle className="text-xl md:text-2xl text-orange-600">{activeLoading ? '…' : activeDeliveries.length}</CardTitle>
                  </CardHeader>
                  <CardContent className="px-4 pb-4 mt-auto">
                    <div className="flex items-center text-xs text-muted-foreground">
                      <Truck className="w-3 h-3 mr-1" />
                      Livraisons actives
                    </div>
                  </CardContent>
                </Card>

                <Card className="hover:shadow-md transition-shadow flex flex-col">
                  <CardHeader className="pb-3 px-4 py-3">
                    <CardDescription className="text-[10px] md:text-xs text-black">Terminées</CardDescription>
                    <CardTitle className="text-xl md:text-2xl text-green-600">{livreurInfo.totalDeliveries}</CardTitle>
                  </CardHeader>
                  <CardContent className="px-4 pb-4 mt-auto">
                    <div className="flex items-center text-xs text-muted-foreground">
                      <CheckCircle2 className="w-3 h-3 mr-1" />
                      Livraisons effectuées
                    </div>
                  </CardContent>
                </Card>

                <Card className="hover:shadow-md transition-shadow flex flex-col">
                  <CardHeader className="pb-3 px-4 py-3">
                    <CardDescription className="text-[10px] md:text-xs text-black">Disponibles</CardDescription>
                    <CardTitle className="text-xl md:text-2xl text-blue-600">{availableLoading ? '…' : availableDeliveries.length}</CardTitle>
                  </CardHeader>
                  <CardContent className="px-4 pb-4 mt-auto">
                    <div className="flex items-center text-xs text-muted-foreground">
                      <Megaphone className="w-3 h-3 mr-1" />
                      Annonces ouvertes
                    </div>
                  </CardContent>
                </Card>

                <Card className="hover:shadow-md transition-shadow flex flex-col">
                  <CardHeader className="pb-3 px-4 py-3">
                    <CardDescription className="text-[10px] md:text-xs text-black">Restantes</CardDescription>
                    <CardTitle className="text-xl md:text-2xl text-amber-600">{Math.max(0, 30 - activeDeliveries.length)}</CardTitle>
                  </CardHeader>
                  <CardContent className="px-4 pb-4 mt-auto">
                    <div className="flex items-center text-xs text-muted-foreground">
                      <Target className="w-3 h-3 mr-1" />
                      Places offre en cours
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Wallet Section */}
              <Card className="relative overflow-hidden border-2 border-orange-100 bg-gradient-to-br from-orange-50 via-white to-orange-50/30">
                <div className="absolute top-0 right-0 w-32 h-32 opacity-5">
                  <GoogleWalletIcon className="w-full h-full" />
                </div>
                <CardHeader className="pb-2">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-base md:text-lg flex items-center gap-2">
                      <GoogleWalletIcon className="w-6 h-6" />
                      Mon Wallet
                    </CardTitle>
                    <Badge className="bg-orange-100 text-orange-700 border-orange-300 hover:bg-orange-100">
                      <DollarSign className="w-3 h-3 mr-1" />
                      Actif
                    </Badge>
                  </div>
                  <CardDescription className="text-xs md:text-sm">Vos gains et votre solde disponible</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex items-end gap-2">
                    <span className="text-3xl md:text-4xl font-bold text-gray-900">{fmt(livreurInfo.totalEarnings)}</span>
                    <span className="text-sm text-gray-500 mb-1">FCFA</span>
                  </div>
                  <div className="flex items-center gap-1 mt-1 text-xs text-green-600">
                    <TrendingUp className="w-3 h-3" />
                    <span>+12% ce mois</span>
                  </div>
                  <div className="grid grid-cols-2 gap-3 mt-4">
                    <div className="bg-white/80 backdrop-blur-sm rounded-lg p-3 border border-gray-100">
                      <p className="text-xs text-gray-500">Ce mois</p>
                      <p className="text-lg font-bold text-gray-900">45,000 <span className="text-xs font-normal text-gray-500">FCFA</span></p>
                    </div>
                    <div className="bg-white/80 backdrop-blur-sm rounded-lg p-3 border border-gray-100">
                      <p className="text-xs text-gray-500">Disponible</p>
                      <p className="text-lg font-bold text-green-600">38,500 <span className="text-xs font-normal text-gray-500">FCFA</span></p>
                    </div>
                  </div>
                  <Button className="mt-4 w-full bg-gradient-to-r from-orange-500 to-white text-orange-600 font-medium border border-orange-200 hover:from-orange-500 hover:to-orange-50" size="sm" onClick={() => router.push('/livreur/wallet')}>
                    <GoogleWalletIcon className="w-4 h-4 mr-2" />
                    Ouvrir mon Wallet
                  </Button>
                </CardContent>
              </Card>

              {/* Quick Actions */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6">
                <Card className="cursor-pointer hover:shadow-md transition-shadow" onClick={() => setActiveTab('annonces')}>
                  <CardHeader>
                    <CardTitle className="text-base md:text-lg flex items-center gap-2">
                      <Megaphone className="w-4 h-4 md:w-5 md:h-5 text-orange-500" />
                      Voir les annonces
                    </CardTitle>
                    <CardDescription className="text-xs md:text-sm">Consultez les annonces disponibles et souscrivez aux livraisons</CardDescription>
                  </CardHeader>
                </Card>

                <Card className="cursor-pointer hover:shadow-md transition-shadow" onClick={() => setActiveTab('livraisons')}>
                  <CardHeader>
                    <CardTitle className="text-base md:text-lg flex items-center gap-2">
                      <Truck className="w-4 h-4 md:w-5 md:h-5 text-orange-500" />
                      Mes livraisons
                    </CardTitle>
                    <CardDescription className="text-xs md:text-sm">Suivez vos livraisons en cours et gérez vos tournées</CardDescription>
                  </CardHeader>
                </Card>

                <Card className="cursor-pointer hover:shadow-md transition-shadow" onClick={() => router.push('/livreur/historique')}>
                  <CardHeader>
                    <CardTitle className="text-base md:text-lg flex items-center gap-2">
                      <History className="w-4 h-4 md:w-5 md:h-5 text-orange-500" />
                      Historique
                    </CardTitle>
                    <CardDescription className="text-xs md:text-sm">Consultez l'historique de vos livraisons effectuées</CardDescription>
                  </CardHeader>
                </Card>

                <Card className="cursor-pointer hover:shadow-md transition-shadow border-2 border-orange-100 hover:border-orange-300 bg-gradient-to-br from-orange-50/50 to-white" onClick={() => router.push('/livreur/wallet')}>
                  <CardHeader>
                    <CardTitle className="text-base md:text-lg flex items-center gap-2">
                      <GoogleWalletIcon className="w-5 h-5 md:w-6 md:h-6" />
                      Mon Wallet
                    </CardTitle>
                    <CardDescription className="text-xs md:text-sm">Consultez votre solde, vos gains et retirez vos fonds</CardDescription>
                  </CardHeader>
                </Card>

                <Card className="cursor-pointer hover:shadow-md transition-shadow" onClick={() => router.push('/livreur/profil')}>
                  <CardHeader>
                    <CardTitle className="text-base md:text-lg flex items-center gap-2">
                      <UserCircle className="w-4 h-4 md:w-5 md:h-5 text-orange-500" />
                      Mon profil
                    </CardTitle>
                    <CardDescription className="text-xs md:text-sm">Gérez vos informations personnelles et paramètres</CardDescription>
                  </CardHeader>
                </Card>
              </div>

              {/* Active Deliveries Preview */}
              <Card>
                <CardHeader className="flex items-center justify-between">
                  <CardTitle className="text-lg">Livraisons en cours</CardTitle>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setActiveTab('livraisons')}
                    className="text-orange-600 hover:text-orange-700"
                  >
                    Voir tout
                  </Button>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {activeDeliveries.length === 0 ? (
                      <div className="text-center py-8">
                        <Truck className="w-10 h-10 text-gray-300 mx-auto mb-3" />
                        <p className="text-sm text-gray-500">Aucune livraison en cours</p>
                        <p className="text-xs text-gray-400 mt-1">Souscrivez à une annonce pour commencer</p>
                      </div>
                    ) : (
                      activeDeliveries.slice(0, 2).map((delivery) => (
                        <div key={delivery.id} className="p-3 bg-gray-50 rounded-lg border hover:bg-gray-100 transition-colors">
                          <div className="flex items-start justify-between">
                            <div className="flex-1">
                              <div className="flex items-center gap-2 mb-2">
                                <span className="text-sm font-semibold text-gray-900">{delivery.title}</span>
                                <Badge variant="outline" className="bg-orange-100 text-orange-700 border-orange-300">
                                  <Package className="w-3 h-3 mr-1" />
                                  {delivery.status === 'ASSIGNED' ? 'Assignée' : 'Souscrit'}
                                </Badge>
                              </div>
                              <div className="flex items-start gap-2">
                                <MapPin className="w-4 h-4 text-gray-500 mt-0.5 flex-shrink-0" />
                                <div className="space-y-1 flex-1">
                                  <p className="text-xs text-gray-700">
                                    <span className="font-medium">Retrait:</span> {delivery.pickupAddress?.city || 'N/A'}
                                  </p>
                                  <p className="text-xs text-gray-700">
                                    <span className="font-medium">Livraison:</span> {delivery.deliveryAddress?.city || 'N/A'}
                                  </p>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          {activeTab === 'annonces' && (
            <>
              <div className="grid lg:grid-cols-2 gap-4">
                {availableLoading ? (
                  <div className="col-span-2 flex items-center justify-center py-16">
                    <div className="w-8 h-8 border-4 border-orange-500 border-t-transparent rounded-full animate-spin" />
                  </div>
                ) : availableDeliveries.length === 0 ? (
                  <div className="col-span-2 text-center py-16">
                    <Megaphone className="w-12 h-12 text-gray-300 mx-auto mb-4" />
                    <h3 className="text-lg font-semibold text-gray-700 mb-2">Aucune annonce disponible</h3>
                    <p className="text-sm text-gray-500">Revenez plus tard pour voir les nouvelles annonces</p>
                  </div>
                ) : availableDeliveries.map((delivery) => (
                  <Card key={delivery.id} className="bg-white border border-gray-200 shadow-md hover:shadow-lg transition-shadow rounded-xl">
                    <CardHeader className="pb-3">
                      <div className="flex items-start justify-between">
                        <div className="space-y-1">
                          <CardTitle className="text-base">{delivery.title}</CardTitle>
                          <p className="text-[10px] text-orange-600 font-medium italic">
                            {delivery.pickupAddress?.city || 'N/A'} → {delivery.deliveryAddress?.city || 'N/A'}
                          </p>
                        </div>
                        {delivery.amount && (
                          <div className="flex items-center gap-1 bg-green-50 px-2 py-1 rounded">
                            <DollarSign className="w-3 h-3 text-green-600" />
                            <span className="text-sm font-semibold text-green-700">{fmt(delivery.amount)} FCFA</span>
                          </div>
                        )}
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      {delivery.description && (
                        <p className="text-sm text-gray-500 line-clamp-2">{delivery.description}</p>
                      )}
                      <div className="flex items-start gap-2">
                        <MapPin className="w-4 h-4 text-orange-500 mt-0.5 flex-shrink-0" />
                        <div className="space-y-2 flex-1">
                          <div className="flex items-center gap-2">
                            <div className="w-2 h-2 bg-green-500 rounded-full" />
                            <p className="text-sm text-gray-700">
                              <span className="font-medium">Retrait:</span> {delivery.pickupAddress?.street || delivery.pickupAddress?.city || 'N/A'}
                            </p>
                          </div>
                          <div className="flex items-center gap-2">
                            <div className="w-2 h-2 bg-red-500 rounded-full" />
                            <p className="text-sm text-gray-700">
                              <span className="font-medium">Livraison:</span> {delivery.deliveryAddress?.street || delivery.deliveryAddress?.city || 'N/A'}
                            </p>
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center justify-between text-sm text-gray-600 pt-2 border-t">
                        {delivery.distance && (
                          <div className="flex items-center gap-2">
                            <Navigation className="w-4 h-4" />
                            <span>{delivery.distance.toFixed(1)} km</span>
                          </div>
                        )}
                        {delivery.amount && (
                          <div className="flex items-center gap-1">
                            <DollarSign className="w-4 h-4 text-green-600" />
                            <span className="font-semibold text-green-600">{fmt(delivery.amount)} FCFA</span>
                          </div>
                        )}
                      </div>

                      <div className="flex gap-2 pt-2">
                        <Button
                          size="sm"
                          variant="outline"
                          className="flex-1 border-orange-500 text-orange-600 hover:bg-orange-50 hover:text-orange-700"
                          onClick={() => { setSelectedDelivery(delivery); setDetailsOpen(true) }}
                        >
                          Voir les détails
                        </Button>
                        <Button
                          size="sm"
                          disabled={pendingSubscriptions.has(delivery.id) || subscribedIds.has(delivery.id)}
                          className={cn(
                            "flex-1 shadow-md transform active:scale-95 transition-all text-white font-medium",
                            (pendingSubscriptions.has(delivery.id) || subscribedIds.has(delivery.id))
                              ? "bg-gray-400 cursor-not-allowed"
                              : "bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-600 hover:to-amber-600"
                          )}
                          onClick={() => handleAcceptDelivery(delivery.id)}
                        >
                          {(pendingSubscriptions.has(delivery.id) || subscribedIds.has(delivery.id))
                            ? "En attente de traitement"
                            : "Souscrire à l'annonce"}
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>

              <Dialog open={detailsOpen} onOpenChange={(o) => { setDetailsOpen(o); if (!o) { setSelectedDelivery(null); } }}>
                <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
                  <DialogHeader className="border-b pb-4">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 bg-orange-100 dark:bg-orange-900/30 rounded-xl flex items-center justify-center">
                        <Package className="w-6 h-6 text-orange-600 dark:text-orange-400" />
                      </div>
                      <div>
                        <DialogTitle className="text-xl">{selectedDelivery?.title || "Détails de l'annonce"}</DialogTitle>
                        <DialogDescription className="text-xs font-mono text-orange-600">{selectedDelivery?.id}</DialogDescription>
                      </div>
                    </div>
                  </DialogHeader>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6 py-6">
                    {/* Left Column: Route Info & Map */}
                    <div className="space-y-4">
                      <div className="bg-gray-50 dark:bg-gray-900/50 p-4 rounded-xl space-y-4">
                        <div className="flex items-start gap-3">
                          <div className="w-2 h-2 bg-green-500 rounded-full mt-2" />
                          <div>
                            <p className="text-xs text-gray-500 uppercase font-bold">Lieu de Retrait</p>
                            <p className="text-sm text-gray-700">
                              {selectedDelivery?.pickupAddress?.street && `${selectedDelivery.pickupAddress.street}, `}
                              {selectedDelivery?.pickupAddress?.district && `${selectedDelivery.pickupAddress.district}, `}
                              {selectedDelivery?.pickupAddress?.city || 'N/A'}
                            </p>
                          </div>
                        </div>
                        <div className="flex items-start gap-3">
                          <div className="w-2 h-2 bg-red-500 rounded-full mt-2" />
                          <div>
                            <p className="text-xs text-gray-500 uppercase font-bold">Lieu de Livraison</p>
                            <p className="text-sm text-gray-700">
                              {selectedDelivery?.deliveryAddress?.street && `${selectedDelivery.deliveryAddress.street}, `}
                              {selectedDelivery?.deliveryAddress?.district && `${selectedDelivery.deliveryAddress.district}, `}
                              {selectedDelivery?.deliveryAddress?.city || 'N/A'}
                            </p>
                          </div>
                        </div>
                      </div>

                      {/* Map */}
                      <div className="rounded-xl overflow-hidden border border-gray-200 shadow-sm h-64 relative z-0">
                        {selectedDelivery?.pickupAddress?.latitude && selectedDelivery?.deliveryAddress?.latitude && (
                          <MapLeaflet
                            center={[
                              (selectedDelivery.pickupAddress.latitude + selectedDelivery.deliveryAddress.latitude) / 2,
                              (selectedDelivery.pickupAddress.longitude + selectedDelivery.deliveryAddress.longitude) / 2
                            ]}
                            zoom={12}
                            markers={[
                              { position: [selectedDelivery.pickupAddress.latitude, selectedDelivery.pickupAddress.longitude], label: "Retrait", color: "#f97316" },
                              { position: [selectedDelivery.deliveryAddress.latitude, selectedDelivery.deliveryAddress.longitude], label: "Livraison", color: "#10b981" }
                            ]}
                            route={activeRoute}
                          />
                        )}
                      </div>

                      <div className="flex justify-between items-center p-4 bg-orange-50 dark:bg-orange-900/20 rounded-xl">
                        {selectedDelivery?.distance && (
                          <div className="flex items-center gap-2">
                            <Navigation className="w-5 h-5 text-orange-600" />
                            <span className="font-bold">{selectedDelivery.distance.toFixed(1)} km</span>
                          </div>
                        )}
                        {selectedDelivery?.duration && (
                          <div className="flex items-center gap-2">
                            <Clock className="w-5 h-5 text-orange-600" />
                            <span className="font-bold">{Math.round(selectedDelivery.duration)} min</span>
                          </div>
                        )}
                        {selectedDelivery?.amount && (
                          <div className="text-lg font-black text-orange-600">
                            {fmt(selectedDelivery.amount)} FCFA
                          </div>
                        )}
                      </div>

                      {/* Transport & Payment info */}
                      <div className="grid grid-cols-2 gap-3 text-sm">
                        {selectedDelivery?.transportMethod && (
                          <div className="bg-gray-50 dark:bg-gray-800 p-3 rounded-lg">
                            <p className="text-xs text-gray-500">Mode de transport</p>
                            <p className="font-medium capitalize">{selectedDelivery.transportMethod}</p>
                          </div>
                        )}
                        {selectedDelivery?.paymentMethod && (
                          <div className="bg-gray-50 dark:bg-gray-800 p-3 rounded-lg">
                            <p className="text-xs text-gray-500">Paiement</p>
                            <p className="font-medium capitalize">{selectedDelivery.paymentMethod}</p>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Right Column: Description, Packet & Recipient */}
                    <div className="space-y-4">
                      {selectedDelivery?.description && (
                        <div>
                          <h4 className="text-sm font-bold text-gray-900 dark:text-gray-100 uppercase tracking-wider mb-2">Description</h4>
                          <p className="text-sm text-gray-600">{selectedDelivery.description}</p>
                        </div>
                      )}

                      {/* Packet Details */}
                      {selectedDelivery?.packet && (
                        <div>
                          <h4 className="text-sm font-bold text-gray-900 dark:text-gray-100 uppercase tracking-wider mb-3 border-b pb-1">Détails du Colis</h4>
                          <div className="grid grid-cols-2 gap-y-3 gap-x-2 text-sm">
                            {selectedDelivery.packet.designation && (
                              <div>
                                <p className="text-xs text-gray-500">Désignation</p>
                                <p className="font-medium">{selectedDelivery.packet.designation}</p>
                              </div>
                            )}
                            {selectedDelivery.packet.weight && (
                              <div>
                                <p className="text-xs text-gray-500">Poids</p>
                                <p className="font-medium">{selectedDelivery.packet.weight} kg</p>
                              </div>
                            )}
                            {selectedDelivery.packet.length && selectedDelivery.packet.width && selectedDelivery.packet.height && (
                              <div className="col-span-2">
                                <p className="text-xs text-gray-500">Dimensions (L × l × H)</p>
                                <p className="font-medium">{selectedDelivery.packet.length} × {selectedDelivery.packet.width} × {selectedDelivery.packet.height} cm</p>
                              </div>
                            )}
                            {selectedDelivery.packet.description && (
                              <div className="col-span-2">
                                <p className="text-xs text-gray-500">Description du colis</p>
                                <p className="text-sm italic text-gray-600">{selectedDelivery.packet.description}</p>
                              </div>
                            )}
                          </div>
                        </div>
                      )}

                      {/* Recipient Info */}
                      <div className="border-t pt-4">
                        <h4 className="text-sm font-bold text-gray-900 dark:text-gray-100 uppercase tracking-wider mb-3">Destinataire</h4>
                        <div className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-xl space-y-2">
                          {(selectedDelivery?.recipientFirstName || selectedDelivery?.recipientLastName) && (
                            <div className="flex items-center gap-3">
                              <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center text-blue-600 font-bold">
                                {selectedDelivery?.recipientFirstName?.charAt(0) || '?'}
                              </div>
                              <p className="font-bold text-gray-900">{selectedDelivery?.recipientFirstName} {selectedDelivery?.recipientLastName}</p>
                            </div>
                          )}
                          {selectedDelivery?.recipientPhone && (
                            <div className="flex items-center gap-2 text-sm text-gray-600">
                              <Phone className="w-4 h-4" />
                              <span>{selectedDelivery.recipientPhone}</span>
                            </div>
                          )}
                          {selectedDelivery?.recipientEmail && (
                            <div className="flex items-center gap-2 text-sm text-gray-600">
                              <Mail className="w-4 h-4" />
                              <span>{selectedDelivery.recipientEmail}</span>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                </DialogContent>
              </Dialog>
            </>
          )}

          {activeTab === 'livraisons' && (
            <>
              {activeLoading ? (
                <div className="flex items-center justify-center py-16">
                  <div className="w-8 h-8 border-4 border-orange-500 border-t-transparent rounded-full animate-spin" />
                </div>
              ) : activeDeliveries.length === 0 ? (
                <div className="text-center py-16">
                  <Truck className="w-12 h-12 text-gray-300 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-gray-700 mb-2">Aucune livraison</h3>
                  <p className="text-sm text-gray-500">Souscrivez à une annonce pour voir vos livraisons ici</p>
                  <Button
                    className="mt-4 bg-gradient-to-r from-orange-500 to-amber-500"
                    onClick={() => setActiveTab('annonces')}
                  >
                    Voir les annonces
                  </Button>
                </div>
              ) : (
                <div className="grid gap-4 mb-6">
                  {activeDeliveries.map((delivery) => (
                    <Card key={delivery.id} className="bg-white border border-gray-200 shadow-md hover:shadow-lg transition-shadow rounded-xl">
                      <CardHeader className="pb-3">
                        <div className="flex items-start justify-between">
                          <div className="space-y-1">
                            <CardTitle className="text-base">{delivery.title}</CardTitle>
                            <p className="text-[10px] text-gray-400 italic">
                              {delivery.pickupAddress?.city || 'N/A'} → {delivery.deliveryAddress?.city || 'N/A'}
                            </p>
                          </div>
                          <Badge variant="outline" className={cn(
                            delivery.status === 'ASSIGNED'
                              ? 'bg-green-100 text-green-700 border-green-300'
                              : 'bg-orange-100 text-orange-700 border-orange-300'
                          )}>
                            {delivery.status === 'ASSIGNED' ? (
                              <><CheckCircle2 className="w-3 h-3 mr-1" /> Assignée</>
                            ) : (
                              <><Package className="w-3 h-3 mr-1" /> Souscrit</>
                            )}
                          </Badge>
                        </div>
                      </CardHeader>
                      <CardContent className="space-y-3">
                        {delivery.description && (
                          <p className="text-sm text-gray-500 line-clamp-2">{delivery.description}</p>
                        )}
                        <div className="flex items-start gap-2">
                          <MapPin className="w-4 h-4 text-orange-500 mt-0.5 flex-shrink-0" />
                          <div className="space-y-2 flex-1">
                            <div className="flex items-center gap-2">
                              <div className="w-2 h-2 bg-green-500 rounded-full" />
                              <p className="text-sm text-gray-700">
                                <span className="font-medium">Retrait:</span> {delivery.pickupAddress?.street || delivery.pickupAddress?.city || 'N/A'}
                              </p>
                            </div>
                            <div className="flex items-center gap-2">
                              <div className="w-2 h-2 bg-red-500 rounded-full" />
                              <p className="text-sm text-gray-700">
                                <span className="font-medium">Livraison:</span> {delivery.deliveryAddress?.street || delivery.deliveryAddress?.city || 'N/A'}
                              </p>
                            </div>
                          </div>
                        </div>

                        <div className="flex items-center justify-between text-sm text-gray-600 pt-2 border-t">
                          {delivery.distance && (
                            <div className="flex items-center gap-2">
                              <Navigation className="w-4 h-4" />
                              <span>{delivery.distance.toFixed(1)} km</span>
                            </div>
                          )}
                          {delivery.amount && (
                            <div className="flex items-center gap-2">
                              <DollarSign className="w-4 h-4 text-green-600" />
                              <span className="font-semibold text-green-600">{fmt(delivery.amount)} FCFA</span>
                            </div>
                          )}
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </>
          )}
        </div>
      </main >



      {/* Desktop Footer */}
      < footer className="hidden md:block py-6 bg-white border-t border-gray-100 mt-auto" >
        <div className="max-w-7xl mx-auto px-4 text-center text-sm text-gray-500">
          <p>© 2025 TiiBnTick - Espace Livreur • Disponible 24h/24</p>
        </div>
      </footer >
    </div >
  )
}

export default withAuth(LivreurDashboard, ['LIVREUR'])
 
