'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
  DialogClose,
} from '@/components/ui/dialog'
import { withAuth } from '@/components/hoc/withAuth'
import { useAuth } from '@/context/AuthContext'
import { useToast } from '@/hooks/use-toast'
import {
  ArrowLeft,
  TrendingUp,
  TrendingDown,
  DollarSign,
  ArrowUpRight,
  ArrowDownLeft,
  Wallet as WalletIcon,
  Clock,
  CheckCircle2,
  XCircle,
  CreditCard,
  Smartphone,
  Building2,
  Send,
  Plus,
  ChevronRight,
  Download,
  Eye,
  EyeOff,
  Info,
  Shield,
  Star,
  User,
  LogOut,
  Menu,
  X,
  Bell,
  Settings,
  LayoutDashboard,
  Megaphone,
  Truck,
  History,
  UserCircle,
} from 'lucide-react'
import { cn } from '@/lib/utils'

// Google Wallet-style icon (orange & white)
function GoogleWalletIcon({ className = 'w-5 h-5' }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
      <rect x="4" y="10" width="28" height="28" rx="5" fill="#F97316" />
      <rect x="16" y="6" width="28" height="28" rx="5" fill="#fff" stroke="#FDBA74" strokeWidth="1" />
      <rect x="16" y="6" width="28" height="7" rx="5" fill="#FFF7ED" />
      <rect x="16" y="6" width="28" height="7" rx="5" fill="url(#wlt-grad-top)" />
      <rect x="16" y="27" width="28" height="7" rx="0" fill="#FED7AA" />
      <rect x="16" y="27" width="28" height="7" rx="5" fill="url(#wlt-grad-bottom)" />
      <path d="M26 20L23 26L20 20H18L22.5 28L21 31H23L29 20H26Z" fill="#F97316" />
      <path d="M32 20L29 26L26 20H24L28.5 28L27 31H29L35 20H32Z" fill="#F97316" opacity="0.7" />
      <defs>
        <linearGradient id="wlt-grad-top" x1="16" y1="6" x2="44" y2="13">
          <stop offset="0" stopColor="#FDBA74" />
          <stop offset="0.5" stopColor="#FFFFFF" />
          <stop offset="1" stopColor="#FED7AA" />
        </linearGradient>
        <linearGradient id="wlt-grad-bottom" x1="16" y1="27" x2="44" y2="34">
          <stop offset="0" stopColor="#FDBA74" />
          <stop offset="1" stopColor="#F97316" />
        </linearGradient>
      </defs>
    </svg>
  )
}

// Mock transactions
const mockTransactions = [
  { id: 'TXN001', type: 'credit' as const, label: 'Livraison Abidjan → Cocody', amount: 3500, date: '2025-01-15 14:30', status: 'completed' as const },
  { id: 'TXN002', type: 'credit' as const, label: 'Livraison Plateau → Marcory', amount: 2000, date: '2025-01-15 11:15', status: 'completed' as const },
  { id: 'TXN003', type: 'debit' as const, label: 'Retrait Mobile Money', amount: 15000, date: '2025-01-14 18:00', status: 'completed' as const },
  { id: 'TXN004', type: 'credit' as const, label: 'Livraison Yopougon → Zone 4', amount: 4000, date: '2025-01-14 09:45', status: 'completed' as const },
  { id: 'TXN005', type: 'credit' as const, label: 'Livraison Treichville → Bouaké', amount: 8000, date: '2025-01-13 16:20', status: 'completed' as const },
  { id: 'TXN006', type: 'debit' as const, label: 'Retrait Mobile Money', amount: 10000, date: '2025-01-12 12:00', status: 'completed' as const },
  { id: 'TXN007', type: 'credit' as const, label: 'Livraison Bingerville → Abidjan', amount: 2500, date: '2025-01-12 08:30', status: 'pending' as const },
  { id: 'TXN008', type: 'credit' as const, label: 'Bonus performance', amount: 5000, date: '2025-01-11 20:00', status: 'completed' as const },
  { id: 'TXN009', type: 'credit' as const, label: 'Livraison Adjamé → Plateau', amount: 3000, date: '2025-01-10 15:10', status: 'completed' as const },
  { id: 'TXN010', type: 'debit' as const, label: 'Retrait vers compte bancaire', amount: 20000, date: '2025-01-09 10:00', status: 'failed' as const },
]

export function LivreurWallet() {
  const router = useRouter()
  const { toast } = useToast()
  const { user, logout } = useAuth()
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const [showRetraitDialog, setShowRetraitDialog] = useState(false)
  const [retraitMethod, setRetraitMethod] = useState<'momo' | 'bank' | null>(null)
  const [retraitAmount, setRetraitAmount] = useState('')
  const [showBalance, setShowBalance] = useState(true)
  const [activeFilter, setActiveFilter] = useState<'all' | 'credit' | 'debit'>('all')

  const livreurInfo = {
    firstName: user?.firstName || 'Livreur',
    lastName: user?.lastName || '',
    rating: user?.rating || 4.8,
  }

  const walletData = {
    totalEarnings: 245000,
    available: 38500,
    pending: 6500,
    thisMonth: 45000,
    lastMonth: 40200,
  }

  const filteredTransactions = mockTransactions.filter(t =>
    activeFilter === 'all' ? true : t.type === activeFilter
  )

  const handleRetrait = () => {
    const amount = parseInt(retraitAmount)
    if (!amount || amount <= 0) {
      toast({ title: 'Erreur', description: 'Entrez un montant valide', variant: 'destructive' })
      return
    }
    if (amount > walletData.available) {
      toast({ title: 'Solde insuffisant', description: 'Le montant dépasse votre solde disponible', variant: 'destructive' })
      return
    }
    if (amount < 500) {
      toast({ title: 'Montant minimum', description: 'Le retrait minimum est de 500 FCFA', variant: 'destructive' })
      return
    }
    toast({ title: 'Demande envoyée', description: `Votre retrait de ${amount.toLocaleString()} FCFA est en cours de traitement.` })
    setShowRetraitDialog(false)
    setRetraitAmount('')
    setRetraitMethod(null)
  }

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-white border-b shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3">
              <Button variant="ghost" size="icon" onClick={() => router.push('/livreur')}>
                <ArrowLeft className="w-5 h-5" />
              </Button>
              <div className="flex items-center gap-2">
                <GoogleWalletIcon className="w-7 h-7" />
                <div>
                  <h1 className="text-lg font-bold">Mon Wallet</h1>
                  <p className="text-xs text-gray-500">Gérez vos finances</p>
                </div>
              </div>
            </div>

            <div className="hidden md:flex items-center gap-2">
              <Button variant="ghost" size="icon" className="relative opacity-50 cursor-not-allowed" disabled>
                <Bell className="w-5 h-5" />
              </Button>
              <div className="flex items-center gap-2 px-3 py-2 bg-orange-50 rounded-lg border border-orange-200">
                <div className="w-8 h-8 bg-gradient-to-br from-orange-500 to-amber-500 rounded-full flex items-center justify-center">
                  <User className="w-4 h-4 text-white" />
                </div>
                <div className="hidden lg:block">
                  <p className="text-sm font-semibold text-gray-900">{livreurInfo.lastName} {livreurInfo.firstName}</p>
                  <div className="flex items-center gap-1">
                    <Star className="w-3 h-3 text-yellow-500 fill-current" />
                    <span className="text-xs text-gray-600">{livreurInfo.rating}</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Mobile menu */}
            <div className="md:hidden flex items-center gap-2">
              <Button variant="ghost" size="icon" onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
                {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </Button>
            </div>
          </div>

          {mobileMenuOpen && (
            <nav className="md:hidden border-t bg-white py-4 space-y-1">
              <Button
                variant="ghost"
                className="w-full justify-start gap-3 rounded-lg text-gray-700"
                onClick={() => { router.push('/livreur'); setMobileMenuOpen(false) }}
              >
                <LayoutDashboard className="w-5 h-5" />
                Dashboard
              </Button>
              <Button
                variant="ghost"
                className="w-full justify-start gap-3 rounded-lg bg-orange-50 text-orange-600 font-semibold"
                onClick={() => setMobileMenuOpen(false)}
              >
                <GoogleWalletIcon className="w-5 h-5" />
                Mon Wallet
              </Button>
              <Button
                variant="ghost"
                className="w-full justify-start gap-3 rounded-lg text-gray-700"
                onClick={() => { router.push('/livreur/historique'); setMobileMenuOpen(false) }}
              >
                <History className="w-5 h-5" />
                Historique
              </Button>
              <Button
                variant="ghost"
                className="w-full justify-start gap-3 rounded-lg text-gray-700"
                onClick={() => { router.push('/livreur/profil'); setMobileMenuOpen(false) }}
              >
                <UserCircle className="w-5 h-5" />
                Mon profil
              </Button>
              <div className="h-px bg-gray-100 mx-2" />
              <Button variant="ghost" className="w-full justify-start gap-3 rounded-lg text-red-600 hover:bg-red-50" onClick={logout}>
                <LogOut className="w-5 h-5" />
                Déconnexion
              </Button>
            </nav>
          )}
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 p-4 sm:p-6 lg:p-8">
        <div className="max-w-3xl mx-auto space-y-6">

          {/* Solde principal */}
          <Card className="relative overflow-hidden border-2 border-orange-100 bg-gradient-to-br from-orange-500 via-orange-400 to-amber-400 text-white">
            <div className="absolute top-0 right-0 w-40 h-40 opacity-10">
              <GoogleWalletIcon className="w-full h-full" />
            </div>
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <CardTitle className="text-sm font-medium text-orange-100 flex items-center gap-2">
                  <WalletIcon className="w-4 h-4" />
                  Solde disponible
                </CardTitle>
                <Button
                  variant="ghost"
                  size="icon"
                  className="text-white/80 hover:text-white hover:bg-white/10"
                  onClick={() => setShowBalance(!showBalance)}
                >
                  {showBalance ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="flex items-end gap-2 mb-1">
                <span className="text-4xl md:text-5xl font-bold">
                  {showBalance ? walletData.available.toLocaleString() : '•••••'}
                </span>
                <span className="text-sm text-orange-100 mb-2">FCFA</span>
              </div>
              <div className="flex items-center gap-4 mt-4">
                <div className="flex-1">
                  <p className="text-xs text-orange-100">Ce mois</p>
                  <p className="text-lg font-bold">{showBalance ? walletData.thisMonth.toLocaleString() : '••••'} <span className="text-xs font-normal text-orange-100">FCFA</span></p>
                </div>
                <div className="flex-1">
                  <p className="text-xs text-orange-100">En attente</p>
                  <p className="text-lg font-bold">{showBalance ? walletData.pending.toLocaleString() : '••••'} <span className="text-xs font-normal text-orange-100">FCFA</span></p>
                </div>
                <div className="flex items-center gap-1 text-xs text-green-200">
                  <TrendingUp className="w-3 h-3" />
                  <span>+{showBalance ? '12' : '•'}% vs mois dernier</span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Actions rapides */}
          <div className="grid grid-cols-2 gap-3">
            <Button
              className="h-auto py-4 flex flex-col items-center gap-2 bg-gradient-to-br from-orange-500 to-amber-500 hover:from-orange-600 hover:to-amber-600 text-white border-0"
              onClick={() => { setRetraitMethod('momo'); setShowRetraitDialog(true) }}
            >
              <Download className="w-6 h-6" />
              <span className="text-sm font-semibold">Retirer</span>
              <span className="text-[10px] text-orange-100">Mobile Money</span>
            </Button>

            <Button
              className="h-auto py-4 flex flex-col items-center gap-2 bg-white border-2 border-orange-200 text-orange-600 hover:bg-orange-50"
              onClick={() => { setRetraitMethod('bank'); setShowRetraitDialog(true) }}
            >
              <Building2 className="w-6 h-6" />
              <span className="text-sm font-semibold">Retirer</span>
              <span className="text-[10px]">Vers compte bancaire</span>
            </Button>
          </div>

          {/* Statistiques */}
          <div className="grid grid-cols-3 gap-3">
            <Card className="hover:shadow-md transition-shadow flex flex-col">
              <CardHeader className="pb-2 px-3 py-3">
                <CardDescription className="text-[10px] text-gray-500">Total gains</CardDescription>
                <CardTitle className="text-lg text-gray-900">{walletData.totalEarnings.toLocaleString()}</CardTitle>
              </CardHeader>
              <CardContent className="px-3 pb-3 mt-auto">
                <div className="flex items-center text-[10px] text-green-600">
                  <TrendingUp className="w-3 h-3 mr-1" />
                  <span>+{Math.round((walletData.thisMonth - walletData.lastMonth) / walletData.lastMonth * 100)}%</span>
                </div>
              </CardContent>
            </Card>

            <Card className="hover:shadow-md transition-shadow flex flex-col">
              <CardHeader className="pb-2 px-3 py-3">
                <CardDescription className="text-[10px] text-gray-500">Mois dernier</CardDescription>
                <CardTitle className="text-lg text-gray-900">{walletData.lastMonth.toLocaleString()}</CardTitle>
              </CardHeader>
              <CardContent className="px-3 pb-3 mt-auto">
                <div className="flex items-center text-[10px] text-muted-foreground">
                  <Clock className="w-3 h-3 mr-1" />
                  <span>Déc 2024</span>
                </div>
              </CardContent>
            </Card>

            <Card className="hover:shadow-md transition-shadow flex flex-col">
              <CardHeader className="pb-2 px-3 py-3">
                <CardDescription className="text-[10px] text-gray-500">En attente</CardDescription>
                <CardTitle className="text-lg text-amber-600">{walletData.pending.toLocaleString()}</CardTitle>
              </CardHeader>
              <CardContent className="px-3 pb-3 mt-auto">
                <div className="flex items-center text-[10px] text-amber-600">
                  <Clock className="w-3 h-3 mr-1" />
                  <span>FCFA</span>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Historique des transactions */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg flex items-center gap-2">
                  <Clock className="w-5 h-5 text-orange-500" />
                  Transactions
                </CardTitle>
              </div>
              {/* Filtres */}
              <div className="flex gap-2 mt-2">
                {[
                  { key: 'all' as const, label: 'Toutes' },
                  { key: 'credit' as const, label: 'Gains' },
                  { key: 'debit' as const, label: 'Retraits' },
                ].map(f => (
                  <button
                    key={f.key}
                    onClick={() => setActiveFilter(f.key)}
                    className={cn(
                      'px-3 py-1.5 rounded-full text-xs font-medium transition-colors',
                      activeFilter === f.key
                        ? 'bg-orange-500 text-white'
                        : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                    )}
                  >
                    {f.label}
                  </button>
                ))}
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-2 max-h-[500px] overflow-y-auto">
                {filteredTransactions.length === 0 ? (
                  <div className="text-center py-8">
                    <WalletIcon className="w-10 h-10 text-gray-300 mx-auto mb-3" />
                    <p className="text-sm text-gray-500">Aucune transaction</p>
                  </div>
                ) : (
                  filteredTransactions.map((txn) => (
                    <div
                      key={txn.id}
                      className="flex items-center justify-between p-3 rounded-lg border border-gray-100 hover:bg-gray-50 transition-colors"
                    >
                      <div className="flex items-center gap-3">
                        <div className={cn(
                          'w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0',
                          txn.type === 'credit' ? 'bg-green-100' : 'bg-red-100'
                        )}>
                          {txn.type === 'credit'
                            ? <ArrowDownLeft className="w-5 h-5 text-green-600" />
                            : <ArrowUpRight className="w-5 h-5 text-red-500" />
                          }
                        </div>
                        <div className="min-w-0">
                          <p className="text-sm font-medium text-gray-900 truncate">{txn.label}</p>
                          <p className="text-xs text-gray-500">{txn.date}</p>
                        </div>
                      </div>
                      <div className="text-right flex-shrink-0 ml-3">
                        <p className={cn(
                          'text-sm font-bold',
                          txn.type === 'credit' ? 'text-green-600' : 'text-red-500'
                        )}>
                          {txn.type === 'credit' ? '+' : '-'}{txn.amount.toLocaleString()} FCFA
                        </p>
                        <Badge
                          variant="outline"
                          className={cn(
                            'text-[9px] px-1.5 py-0',
                            txn.status === 'completed' && 'bg-green-50 text-green-600 border-green-200',
                            txn.status === 'pending' && 'bg-amber-50 text-amber-600 border-amber-200',
                            txn.status === 'failed' && 'bg-red-50 text-red-500 border-red-200'
                          )}
                        >
                          {txn.status === 'completed' ? <><CheckCircle2 className="w-2.5 h-2.5 mr-0.5" />Terminé</> : null}
                          {txn.status === 'pending' ? <><Clock className="w-2.5 h-2.5 mr-0.5" />En attente</> : null}
                          {txn.status === 'failed' ? <><XCircle className="w-2.5 h-2.5 mr-0.5" />Échoué</> : null}
                        </Badge>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </CardContent>
          </Card>

          {/* Info sécurité */}
          <Card className="border-orange-100 bg-orange-50/50">
            <CardContent className="p-4">
              <div className="flex items-start gap-3">
                <Shield className="w-5 h-5 text-orange-500 mt-0.5 flex-shrink-0" />
                <div>
                  <p className="text-sm font-semibold text-gray-900">Sécurité de votre Wallet</p>
                  <p className="text-xs text-gray-600 mt-1">
                    Vos fonds sont protégés. Les retraits sont traités sous 24h ouvrables.
                    Le montant minimum de retrait est de 500 FCFA.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>

      {/* Dialog Retrait */}
      <Dialog open={showRetraitDialog} onOpenChange={setShowRetraitDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Download className="w-5 h-5 text-orange-500" />
              Retirer des fonds
            </DialogTitle>
            <DialogDescription>
              {retraitMethod === 'momo'
                ? 'Effectuez un retrait vers votre compte Mobile Money'
                : 'Effectuez un retrait vers votre compte bancaire'
              }
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 py-2">
            {/* Méthode choisie */}
            <div className="flex items-center gap-3 p-3 bg-orange-50 rounded-lg border border-orange-100">
              {retraitMethod === 'momo' ? (
                <>
                  <Smartphone className="w-6 h-6 text-orange-500" />
                  <div>
                    <p className="text-sm font-semibold text-gray-900">Mobile Money</p>
                    <p className="text-xs text-gray-500">MTN / Moov / Orange Money</p>
                  </div>
                </>
              ) : (
                <>
                  <Building2 className="w-6 h-6 text-orange-500" />
                  <div>
                    <p className="text-sm font-semibold text-gray-900">Virement bancaire</p>
                    <p className="text-xs text-gray-500">Vers votre compte bancaire</p>
                  </div>
                </>
              )}
            </div>

            {/* Solde dispo */}
            <div className="flex items-center justify-between text-sm">
              <span className="text-gray-500">Solde disponible</span>
              <span className="font-bold text-green-600">{walletData.available.toLocaleString()} FCFA</span>
            </div>

            {/* Montant */}
            <div>
              <Label htmlFor="amount" className="text-sm font-medium">Montant (FCFA)</Label>
              <Input
                id="amount"
                type="number"
                placeholder="Entrez le montant"
                value={retraitAmount}
                onChange={(e) => setRetraitAmount(e.target.value)}
                min={500}
                max={walletData.available}
                className="mt-1.5"
              />
              <p className="text-[10px] text-gray-400 mt-1">Minimum : 500 FCFA</p>
            </div>

            {/* Montants rapides */}
            <div className="flex gap-2">
              {[1000, 5000, 10000, 20000].map(amount => (
                <button
                  key={amount}
                  onClick={() => setRetraitAmount(String(amount))}
                  className={cn(
                    'flex-1 py-2 rounded-lg text-xs font-medium border transition-colors',
                    retraitAmount === String(amount)
                      ? 'bg-orange-500 text-white border-orange-500'
                      : 'bg-white text-gray-700 border-gray-200 hover:border-orange-300'
                  )}
                >
                  {amount >= 1000 ? `${amount / 1000}k` : amount}
                </button>
              ))}
            </div>
          </div>

          <DialogFooter className="gap-2 sm:gap-0">
            <DialogClose asChild>
              <Button variant="outline" className="flex-1 sm:flex-none">Annuler</Button>
            </DialogClose>
            <Button
              className="flex-1 sm:flex-none bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-600 hover:to-amber-600 text-white"
              onClick={handleRetrait}
            >
              <Send className="w-4 h-4 mr-2" />
              Confirmer le retrait
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Desktop Footer */}
      <footer className="hidden md:block py-6 bg-white border-t border-gray-100 mt-auto">
        <div className="max-w-7xl mx-auto px-4 text-center text-sm text-gray-500">
          <p>© 2025 TiiBnTick - Espace Livreur • Disponible 24h/24</p>
        </div>
      </footer>
    </div>
  )
}

export default withAuth(LivreurWallet, ['LIVREUR'])