"use client"

import React, { useState, useEffect, useCallback } from 'react'
import { motion } from 'framer-motion'
import { ArrowLeft, Loader2, Clock, AlertTriangle, RefreshCw, SkipForward } from 'lucide-react'
import dynamic from 'next/dynamic'
import { geocode } from '@/services/geocoding'
import { getRoute } from '@/services/routing'
import type { GeoJSON } from 'geojson'

interface RouteData {
  departurePointId: string | null
  arrivalPointId: string | null
  departurePointName: string
  arrivalPointName: string
  distanceKm: number
  durationMinutes?: number
}

interface RouteSelectionStepProps {
  onContinue: (data: RouteData, travelPrice: number) => void
  onBack: () => void
  initialDepartureAddress?: string
  initialArrivalAddress?: string
  initialDepartureCoords?: { lat: number; lon: number }
  initialArrivalCoords?: { lat: number; lon: number }
  transportMethod?: string
}

const MapLeaflet = dynamic(() => import('@/components/MapLeaflet'), {
  ssr: false,
  loading: () => <div className="w-full h-96 bg-gray-100 dark:bg-gray-800 animate-pulse rounded-xl" />
})

const calculateTravelPrice = (distance: number) => {
  if (distance <= 0) return 0
  const baseFee = 500
  const pricePerKm = 80
  return Math.round(baseFee + distance * pricePerKm)
}

export default function RouteSelectionStep({
  onContinue,
  onBack,
  initialDepartureAddress,
  initialArrivalAddress,
  initialDepartureCoords,
  initialArrivalCoords,
  transportMethod
}: RouteSelectionStepProps) {
  const [routeData, setRouteData] = useState<RouteData>({
    departurePointId: null,
    arrivalPointId: null,
    departurePointName: initialDepartureAddress || (initialDepartureCoords ? 'Ma position actuelle' : ''),
    arrivalPointName: initialArrivalAddress || (initialArrivalCoords ? 'Destination' : ''),
    distanceKm: 0,
    durationMinutes: 0
  })

  const [travelPrice, setTravelPrice] = useState(0)
  const [isLoading, setIsLoading] = useState(false)
  const [markers, setMarkers] = useState<any[]>([])
  const [routeGeoJSON, setRouteGeoJSON] = useState<GeoJSON.Feature | null>(null)
  const [mapCenter, setMapCenter] = useState<[number, number]>([5.33, -4.03])
  const [errorMessage, setErrorMessage] = useState<string | null>(null)

  const setupFromAddresses = useCallback(async () => {
    if (!initialDepartureAddress && !initialDepartureCoords) return
    if (!initialArrivalAddress && !initialArrivalCoords) return

    setIsLoading(true)
    setErrorMessage(null)
    try {
      let depLat, depLon, arrLat, arrLon;

      // Helper for geocoding with fallback
      const geocodeWithFallback = async (address: string) => {
        let results = await geocode(address);
        if (results && results.length > 0) return results[0];

        console.warn(`Precise geocoding failed for: ${address}. Retrying with broader query.`);
        const parts = address.split(',');
        if (parts.length > 1) {
          const broaderQuery = parts.slice(-2).join(', ');
          results = await geocode(broaderQuery);
          if (results && results.length > 0) return results[0];
        }
        return null;
      };

      // Gérer le point de départ
      if (initialDepartureCoords) {
        depLat = initialDepartureCoords.lat;
        depLon = initialDepartureCoords.lon;
      } else if (initialDepartureAddress) {
        const depResult = await geocodeWithFallback(initialDepartureAddress);
        if (depResult) {
          depLat = parseFloat(depResult.lat);
          depLon = parseFloat(depResult.lon);
        }
      }

      // Gérer le point d'arrivée
      if (initialArrivalCoords) {
        arrLat = initialArrivalCoords.lat;
        arrLon = initialArrivalCoords.lon;
      } else if (initialArrivalAddress) {
        const arrResult = await geocodeWithFallback(initialArrivalAddress);
        if (arrResult) {
          arrLat = parseFloat(arrResult.lat);
          arrLon = parseFloat(arrResult.lon);
        }
      }

      if (depLat !== undefined && depLon !== undefined && arrLat !== undefined && arrLon !== undefined) {
        setMarkers([
          { position: [depLat, depLon], label: 'Retrait', color: '#f97316' },
          { position: [arrLat, arrLon], label: 'Livraison', color: '#10b981' },
        ]);
        setMapCenter([(depLat + arrLat) / 2, (depLon + arrLon) / 2]);

        try {
          const data = await getRoute(depLat, depLon, arrLat, arrLon, transportMethod);
          if (data && data.routes && data.routes.length > 0) {
            const route = data.routes[0];
            const distanceKm = Math.round((route.distance / 1000) * 100) / 100;
            const durationMinutes = Math.round(route.duration / 60);

            setRouteData(prev => ({
              ...prev,
              distanceKm,
              durationMinutes,
              departurePointName: initialDepartureAddress || 'Ma position actuelle',
              arrivalPointName: initialArrivalAddress || 'Destination',
              departurePointId: 'from-address',
              arrivalPointId: 'to-address'
            }));
            setTravelPrice(calculateTravelPrice(distanceKm));
            setRouteGeoJSON({ type: 'Feature', geometry: route.geometry as any, properties: {} });
            setErrorMessage(null);
          } else {
            console.error('No route data from service');
            setErrorMessage('Impossible de calculer un itinéraire entre ces deux points. Vous pouvez réessayer ou passer cette étape.');
          }
        } catch (routeError: any) {
          console.error('Routing service failed:', routeError);
          setErrorMessage(`Erreur de calcul d'itinéraire: ${routeError.message}. Vous pouvez réessayer ou passer cette étape.`);
        }
      } else {
        setErrorMessage('Impossible de localiser les adresses sur la carte. Vérifiez vos adresses ou passez cette étape.');
      }
    } catch (e: any) {
      console.error('Global setup error:', e);
      setErrorMessage(e.message || 'Erreur lors de la préparation de l\'itinéraire. Vous pouvez réessayer ou passer cette étape.');
    } finally {
      setIsLoading(false);
    }
  }, [initialDepartureAddress, initialArrivalAddress, initialDepartureCoords, initialArrivalCoords, transportMethod])

  useEffect(() => {
    setupFromAddresses()
  }, [setupFromAddresses])

  const handleReset = () => {
    setMarkers([])
    setRouteGeoJSON(null)
    setRouteData({ departurePointId: null, arrivalPointId: null, departurePointName: '', arrivalPointName: '', distanceKm: 0 })
    setTravelPrice(0)
    setMapCenter([5.33, -4.03])
  }

  const handleRetry = () => {
    setErrorMessage(null)
    setupFromAddresses()
  }

  const handleSkip = () => {
    // Allow user to continue with the addresses but without computed route data
    const fallbackData: RouteData = {
      ...routeData,
      departurePointName: initialDepartureAddress || 'Ma position actuelle',
      arrivalPointName: initialArrivalAddress || 'Destination',
      departurePointId: 'from-address',
      arrivalPointId: 'to-address',
      distanceKm: 0,
      durationMinutes: 0
    };
    onContinue(fallbackData, 0)
  }

  const handleSubmit = () => {
    if (routeData.distanceKm > 0) {
      onContinue(routeData, travelPrice)
    }
  }

  const isButtonDisabled = isLoading || (routeData.distanceKm <= 0 && !errorMessage);

  return (
    <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="h-screen flex flex-col bg-gray-50 dark:bg-transparent">
      <div className="bg-white dark:bg-gray-800 shadow-sm border-b border-gray-200 dark:border-gray-700 px-4 py-4 flex-shrink-0">
        <div className="flex items-center gap-4">
          <button onClick={onBack} className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors">
            <ArrowLeft className="w-5 h-5 text-gray-600 dark:text-gray-300" />
          </button>
          <div>
            <h2 className="text-xl font-bold text-gray-800 dark:text-gray-100">Sélection de l'itinéraire</h2>
            <p className="text-sm text-gray-500 dark:text-gray-400">Itinéraire calculé à partir des adresses fournies.</p>
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto">
        <div className="relative h-[350px] lg:h-[450px]">
          <MapLeaflet center={mapCenter} markers={markers} route={routeGeoJSON} />

          {isLoading && (
            <div className="absolute inset-0 flex items-center justify-center z-20 bg-black/10">
              <div className="bg-white dark:bg-gray-800 p-4 rounded-xl shadow-lg flex items-center gap-3">
                <Loader2 className="animate-spin text-orange-500" />
                <span className="text-sm font-medium text-gray-700 dark:text-gray-200">Calcul en cours...</span>
              </div>
            </div>
          )}
        </div>

        <div className="px-4 py-6 max-w-2xl mx-auto">
          <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
            <div className="flex items-center justify-between mb-6">
              <h4 className="text-lg font-bold text-gray-800 dark:text-gray-100">Détails de l'itinéraire</h4>
              <button
                onClick={handleReset}
                className="text-sm font-medium text-orange-600 hover:text-orange-700 dark:text-orange-400 p-2 hover:bg-orange-50 dark:hover:bg-orange-900/20 rounded-lg transition-colors"
                disabled={isLoading}
              >
                Réinitialiser
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <div className="flex items-start gap-4">
                  <div className="mt-1 w-4 h-4 bg-orange-500 rounded-full flex-shrink-0 shadow-[0_0_0_3px_rgba(249,115,22,0.2)]" />
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-1">Point de retrait</p>
                    <p className="font-medium text-gray-800 dark:text-gray-100 leading-snug">{routeData.departurePointName || 'À sélectionner'}</p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="mt-1 w-4 h-4 bg-green-500 rounded-full flex-shrink-0 shadow-[0_0_0_3px_rgba(16,185,129,0.2)]" />
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-1">Point de livraison</p>
                    <p className="font-medium text-gray-800 dark:text-gray-100 leading-snug">{routeData.arrivalPointName || 'À sélectionner'}</p>
                  </div>
                </div>
              </div>

              {routeData.distanceKm > 0 ? (
                <div className="bg-gray-50 dark:bg-gray-900/50 rounded-xl p-4 flex flex-col justify-center border border-gray-100 dark:border-gray-800">
                  <div className="flex justify-between items-center mb-4">
                    <div className="space-y-1">
                      <p className="text-xs text-gray-500 dark:text-gray-400">Distance totale</p>
                      <p className="text-xl font-bold text-gray-800 dark:text-gray-100">{routeData.distanceKm.toFixed(1)} km</p>
                    </div>
                    <div className="text-right">
                      <p className="text-xs text-gray-500 dark:text-gray-400">Coût estimé</p>
                      <p className="text-2xl font-black text-orange-600 dark:text-orange-400">{travelPrice.toLocaleString()} <span className="text-sm font-bold">FCFA</span></p>
                    </div>
                  </div>

                  {routeData.durationMinutes && routeData.durationMinutes > 0 && (
                    <div className="flex items-center gap-2 pt-3 border-t border-gray-200 dark:border-gray-700">
                      <Clock className="w-5 h-5 text-gray-400" />
                      <div>
                        <p className="text-xs text-gray-500 dark:text-gray-400">Durée de route estimée</p>
                        <p className="font-semibold text-gray-800 dark:text-gray-100">{routeData.durationMinutes} minutes</p>
                      </div>
                    </div>
                  )}
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center p-8 border-2 border-dashed border-gray-200 dark:border-gray-700 rounded-xl gap-3">
                  {isLoading ? (
                    <div className="flex flex-col items-center gap-2">
                      <Loader2 className="animate-spin text-orange-500" size={24} />
                      <p className="text-sm text-gray-500 italic">Calcul en cours...</p>
                    </div>
                  ) : errorMessage ? (
                    <div className="flex flex-col items-center gap-3 w-full">
                      <div className="flex items-center gap-2 text-amber-600 dark:text-amber-400">
                        <AlertTriangle size={20} />
                        <p className="text-sm font-medium">Problème de calcul</p>
                      </div>
                      <p className="text-xs text-gray-500 dark:text-gray-400 text-center">{errorMessage}</p>
                      <div className="flex gap-2">
                        <button
                          onClick={handleRetry}
                          className="inline-flex items-center gap-1.5 px-4 py-2 text-sm font-medium text-orange-600 bg-orange-50 dark:bg-orange-900/20 border border-orange-200 dark:border-orange-700 rounded-lg hover:bg-orange-100 dark:hover:bg-orange-900/40 transition-colors"
                        >
                          <RefreshCw size={14} />
                          Réessayer
                        </button>
                        <button
                          onClick={handleSkip}
                          className="inline-flex items-center gap-1.5 px-4 py-2 text-sm font-medium text-gray-600 dark:text-gray-300 bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-600 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
                        >
                          <SkipForward size={14} />
                          Passer cette étape
                        </button>
                      </div>
                    </div>
                  ) : (
                    <p className="text-sm text-gray-500 dark:text-gray-400 text-center italic">
                      Configurez vos adresses pour calculer l'itinéraire
                    </p>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700 px-6 py-4 flex-shrink-0">
        <div className="flex justify-end max-w-2xl mx-auto">
          <motion.button
            onClick={handleSubmit}
            disabled={isButtonDisabled}
            whileHover={!isButtonDisabled ? { scale: 1.02 } : {}}
            whileTap={!isButtonDisabled ? { scale: 0.98 } : {}}
            className="w-full md:w-auto inline-flex items-center justify-center bg-gradient-to-r from-orange-500 to-amber-500 text-white font-bold py-4 px-10 rounded-2xl shadow-lg hover:shadow-xl transition-all disabled:opacity-50 disabled:grayscale disabled:cursor-not-allowed text-lg"
          >
            {isLoading ? (
              <>
                <Loader2 className="animate-spin mr-2" size={20} />
                Calcul...
              </>
            ) : "Continuer vers la signature"}
          </motion.button>
        </div>
      </div>
    </motion.div>
  )
}

