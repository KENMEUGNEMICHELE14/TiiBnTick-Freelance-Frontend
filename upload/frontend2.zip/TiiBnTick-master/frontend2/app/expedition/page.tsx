'use client';
import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import {
  UserIcon as UserOutlineIcon,
  TruckIcon,
  MapPinIcon,
  CreditCardIcon,
  ArrowUturnLeftIcon,
  PencilIcon,
  SparklesIcon,
  ShieldCheckIcon,
  ClockIcon,
  DocumentTextIcon,
} from '@heroicons/react/24/outline';
import {
  CheckCircleIcon as SolidCheckCircleIcon,
  StarIcon,
  BoltIcon,
  GiftIcon,
} from '@heroicons/react/24/solid';
import { supabase } from '@/lib/supabase';
import { motion, AnimatePresence } from 'framer-motion';
import SenderInfoStep from './SenderInfoStep';
import RecipientInfoStep from './RecipientInfoStep';
import PackageInfoStep from './FormulaireColisExpedition';
import RouteSelectionStep from './RouteExpedition';
import SignatureStep from './SignatureStep';
import PaymentStep from './PaymentStepExpedition';
import { CheckCircleIcon, PrinterIcon } from '@heroicons/react/24/outline';
import { UserPlusIcon } from 'lucide-react';
import { pdfService } from '@/services/pdfService';
import { useAuth } from '@/context/AuthContext';
import { packageService, PackageCreationPayload } from '@/services/packageService';

const EXPEDITION_FORM_STORAGE_KEY = 'expedition_form_in_progress';

interface ExpeditionFormData {
  currentStep: number;
  senderData: SenderData;
  recipientData: RecipientData;
  packageData: PackageData;
  routeData: RouteData;
  signatureData: SignatureData;
  pricing: {
    basePrice: number;
    travelPrice: number;
    operatorFee: number;
    totalPrice: number;
  };
}

interface SenderData {
  senderFirstName: string;
  senderLastName: string;
  senderPhone: string;
  senderEmail: string;
  senderCountry: string;
  senderRegion: string;
  senderCity: string;
  senderAddress: string;
  latitude?: number;
  longitude?: number;
}

// 2. Mise à jour de l'interface RecipientData
interface RecipientData {
  recipientFirstName: string;
  recipientLastName: string;
  recipientPhone: string;
  recipientEmail: string;
  recipientCountry: string;
  recipientRegion: string;
  recipientCity: string;
  recipientAddress: string;
  recipientLatitude?: number;
  recipientLongitude?: number;
}
// << CORRIGÉ: Mise à jour de l'interface PackageData >>
interface PackageData {
  photo: File | string | null;
  designation: string;
  description: string;
  weight: string;
  length: string;
  width: string;
  height: string;
  isFragile: boolean;
  isPerishable: boolean;
  transportMethod: ('TRUCK' | 'MOTORBIKE' | 'BIKE' | 'CAR' | 'SCOOTER')[];
}
interface RouteData {
  departurePointId: string | null;
  arrivalPointId: string | null;
  departurePointName: string;
  arrivalPointName: string;
  distanceKm: number;
  durationMinutes?: number;
}
interface SignatureData {
  signatureUrl: string | null;
}
interface LoggedInUser {
  id: string;
  full_name: string | null;
  phone: string | null;
  email?: string;
  address?: string | null;
  lieu_dit?: string | null;
}

const STORAGE_KEY = 'shipping_form_temp_data_v2';

const ShippingSteps = ({ currentStep = 1 }: { currentStep?: number }) => {
  const steps = [
    { number: 1, title: "Expéditeur", icon: <UserOutlineIcon className="w-5 h-5" />, color: "from-orange-400 to-orange-500" },
    { number: 2, title: "Destinataire", icon: <UserOutlineIcon className="w-5 h-5" />, color: "from-orange-400 to-orange-600" },
    { number: 3, title: "Colis", icon: <TruckIcon className="w-5 h-5" />, color: "from-orange-500 to-orange-600" },
    { number: 4, title: "Trajet", icon: <MapPinIcon className="w-5 h-5" />, color: "from-orange-500 to-orange-700" },
    { number: 5, title: "Signature", icon: <PencilIcon className="w-5 h-5" />, color: "from-orange-600 to-orange-700" },
    { number: 6, title: "Paiement", icon: <CreditCardIcon className="w-5 h-5" />, color: "from-orange-600 to-orange-800" },
  ];
  return (
    <div className="flex justify-between items-start mb-6 w-full max-w-5xl mx-auto relative">
      <div className="absolute top-5 left-0 right-0 h-0.5 bg-gray-200 dark:bg-gray-700 rounded-full" />
      <motion.div
        className="absolute top-5 left-0 h-0.5 bg-orange-400 dark:bg-orange-500 rounded-full shadow-sm"
        initial={{ width: '0%' }}
        animate={{ width: `${((currentStep - 1) / (steps.length - 1)) * 100}%` }}
        transition={{ duration: 0.6, ease: "easeInOut" }}
      />
      {steps.map((step, index) => (
        <div key={step.number} className="flex flex-col items-center group text-center relative z-10">
          <motion.div
            className={`relative w-10 h-10 flex items-center justify-center rounded-xl transition-all duration-300 ${step.number <= currentStep
              ? "bg-orange-500 dark:bg-orange-600 text-white shadow-md shadow-orange-500/20 dark:shadow-orange-600/30"
              : "bg-white dark:bg-gray-800 border-2 border-gray-200 dark:border-gray-600 text-gray-400 dark:text-gray-500 shadow-sm"
              }`}
            whileHover={{ scale: 1.05 }}
          >
            {step.number < currentStep ? (
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ duration: 0.3 }}
              >
                <SolidCheckCircleIcon className="w-6 h-6" />
              </motion.div>
            ) : step.number === currentStep ? (
              <motion.div
                animate={{
                  scale: [1, 1.05, 1],
                }}
                transition={{ duration: 1.5, repeat: Infinity }}
              >
                {step.icon}
              </motion.div>
            ) : (
              step.icon
            )}
          </motion.div>
          <motion.p
            className={`text-xs font-semibold mt-1.5 transition-all duration-300 ${step.number <= currentStep
              ? "text-orange-600 dark:text-orange-400"
              : "text-gray-500 dark:text-gray-400"
              }`}
          >
            {step.title}
          </motion.p>
        </div>
      ))}
    </div>
  );
};



export default function ShippingPage() {
  const router = useRouter();
  const { user: authUser } = useAuth();
  const [user, setUser] = useState<LoggedInUser | null>(null);
  const [isLoadingUser, setIsLoadingUser] = useState(true);
  const [isMounted, setIsMounted] = useState(false);
  const [formData, setFormData] = useState<ExpeditionFormData>({
    currentStep: 1,
    senderData: {
      senderFirstName: '', senderLastName: '', senderPhone: '', senderAddress: '',
      senderEmail: '', senderCountry: 'cameroun', senderRegion: 'centre', senderCity: 'Yaoundé'
    },
    recipientData: {
      recipientFirstName: '', recipientLastName: '', recipientPhone: '', recipientEmail: '', recipientAddress: '',
      recipientCountry: 'cameroun', recipientRegion: 'centre', recipientCity: 'Yaoundé'
    },
    packageData: {
      photo: null, designation: '', description: '', weight: '', length: '', width: '', height: '',
      isFragile: false, isPerishable: false,
      transportMethod: []
    },
    routeData: { departurePointId: null, arrivalPointId: null, departurePointName: '', arrivalPointName: '', distanceKm: 0 },
    signatureData: { signatureUrl: null },
    pricing: { basePrice: 0, travelPrice: 0, operatorFee: 0, totalPrice: 0 },
  });

  // États pour l'écran de succès
  const [trackingNumber, setTrackingNumber] = useState('PDL0000000');

  // Generate tracking number only on client side to avoid hydration mismatch
  useEffect(() => {
    if (formData.currentStep === 7 && trackingNumber === 'PDL0000000') {
      setTrackingNumber(`PDL${Date.now().toString().slice(-7)}`);
    }
  }, [formData.currentStep, trackingNumber]);

  // Set mounted flag to prevent hydration issues
  useEffect(() => {
    setIsMounted(true);
  }, []);

  useEffect(() => {
    if (formData.currentStep > 0 && formData.currentStep < 7) {
      try {
        // Protection contre l'objet File lors de la sauvegarde JSON
        const safeData = {
          ...formData,
          packageData: {
            ...formData.packageData,
            photo: typeof formData.packageData.photo === 'string' ? formData.packageData.photo : null
          }
        };
        localStorage.setItem(EXPEDITION_FORM_STORAGE_KEY, JSON.stringify(formData));
      } catch (e) {
        console.error("Erreur de sauvegarde localStorage:", e);
      }
    }
  }, [formData]);

  useEffect(() => {
    if (formData.currentStep < 7 && formData.currentStep > 0) {
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(formData));
      } catch (e) {
        console.error("Erreur de sauvegarde localStorage :", e)
      }
    }
  }, [formData]);

  useEffect(() => {
    const checkUserAndLoadData = async () => {
      let restoredData: Partial<ExpeditionFormData> | null = null;
      let shouldAskToRestore = false;

      try {
        const savedData = localStorage.getItem(EXPEDITION_FORM_STORAGE_KEY);
        if (savedData) {
          restoredData = JSON.parse(savedData);
          // Auto-restore: if a prefill exists (navigated from Publier), apply it immediately
          try {
            setFormData(prev => ({ ...prev, ...restoredData }));
            // remove saved prefill to avoid repeated restores
            localStorage.removeItem(EXPEDITION_FORM_STORAGE_KEY);
            restoredData = null;
            shouldAskToRestore = false;
          } catch (e) {
            console.warn('Impossible de restaurer automatiquement le formulaire:', e);
            shouldAskToRestore = true;
          }
        }
      } catch (e) {
        console.error("Erreur de parsing localStorage:", e);
        localStorage.removeItem(EXPEDITION_FORM_STORAGE_KEY);
      }

      const { data: { session } } = await (supabase.auth.getSession() as any);
      if (session?.user) {
        const { data: profile } = await (supabase.from('profiles').select('*').eq('id', session.user.id).single() as any);
        if (profile) {
          const connectedUser: LoggedInUser = { id: profile.id, full_name: profile.full_name, phone: profile.phone, email: profile.email, address: profile.address, lieu_dit: profile.lieu_dit };
          setUser(connectedUser);

          if (!restoredData) {
            setFormData(prev => ({
              ...prev,
              senderData: {
                // --- CORRECTION: Préserver les champs par défaut comme le pays tout en remplissant le profil ---
                ...prev.senderData,
                senderFirstName: connectedUser.full_name ? connectedUser.full_name.split(' ')[0] : '',
                senderLastName: connectedUser.full_name ? connectedUser.full_name.split(' ').slice(1).join(' ') : '',
                senderPhone: connectedUser.phone || '',
                senderEmail: connectedUser.email || '', // Email ajouté
                senderAddress: connectedUser.address || '',
              }
            }));
          }
        }
      }

      // Fallback: if no Supabase session but backend auth is active, use authUser
      if (!user && authUser && !restoredData) {
        const backendUser: LoggedInUser = {
          id: authUser.id,
          full_name: `${authUser.firstName || ''} ${authUser.lastName || ''}`.trim() || null,
          phone: authUser.phone || null,
          email: authUser.email,
          address: authUser.street || null,
          lieu_dit: null,
        };
        setUser(backendUser);
        setFormData(prev => ({
          ...prev,
          senderData: {
            ...prev.senderData,
            senderFirstName: authUser.firstName || '',
            senderLastName: authUser.lastName || '',
            senderPhone: authUser.phone || '',
            senderEmail: authUser.email || '',
            senderAddress: authUser.street || '',
          }
        }));
      }
      setIsLoadingUser(false);
    };

    checkUserAndLoadData();
  }, []);

  const resetFormAndStartOver = () => {
    localStorage.removeItem(EXPEDITION_FORM_STORAGE_KEY);
    window.location.reload();
  };

  const generateBordereauPDF = async () => {
    const allData = {
      senderLastName: formData.senderData.senderLastName,
      senderFirstName: formData.senderData.senderFirstName,
      senderPhone: formData.senderData.senderPhone,
      recipientName: `${formData.recipientData.recipientFirstName} ${formData.recipientData.recipientLastName}`,
      recipientPhone: formData.recipientData.recipientPhone,
      departurePointName: formData.routeData.departurePointName,
      arrivalPointName: formData.routeData.arrivalPointName,
      designation: formData.packageData.designation,
      weight: formData.packageData.weight,
      isFragile: formData.packageData.isFragile,
      isPerishable: formData.packageData.isPerishable,
      photo: typeof formData.packageData.photo === 'string' ? formData.packageData.photo : null,
      signatureUrl: formData.signatureData.signatureUrl,
      basePrice: formData.pricing.basePrice,
      travelPrice: formData.pricing.travelPrice,
    };
    await pdfService.generateBordereauPDF(
      allData,
      trackingNumber,
      formData.pricing.totalPrice,
      formData.pricing.operatorFee,
      'cash',
    );
  };

  const handleCreateAccount = () => {
    // 1. Préparer les données de l'expéditeur pour le pré-remplissage
    const prefillData = {
      firstName: formData.senderData.senderFirstName,
      lastName: formData.senderData.senderLastName,
      email: formData.senderData.senderEmail,
      phone: formData.senderData.senderPhone,
    };

    // 2. Stocker les données dans localStorage pour que la page d'inscription puisse les lire
    localStorage.setItem('registration_prefill', JSON.stringify(prefillData));

    // 3. Rediriger vers la page d'inscription
    router.push('/register');
  };

  const renderCurrentStep = () => {
    switch (formData.currentStep) {
      case 1:
        return <SenderInfoStep
          initialData={formData.senderData}
          onContinue={(data) => setFormData(prev => ({ ...prev, senderData: data, currentStep: 2 }))}
        />;
      case 2:
        return <RecipientInfoStep
          initialData={formData.recipientData}
          onContinue={(data) => setFormData(prev => ({ ...prev, recipientData: data, currentStep: 3 }))}
          onBack={() => setFormData(prev => ({ ...prev, currentStep: 1 }))}
        />;
      case 3:
        return <PackageInfoStep
          initialData={formData.packageData}
          onContinue={(data, totalPrice) => setFormData(prev => ({
            ...prev,
            packageData: data,
            pricing: { ...prev.pricing, basePrice: totalPrice },
            currentStep: 4
          }))}
          onBack={() => setFormData(prev => ({ ...prev, currentStep: 2 }))}
        />;
      case 4:
        return <RouteSelectionStep
          initialDepartureAddress={
            formData.senderData.senderAddress
              ? `${formData.senderData.senderAddress}, ${formData.senderData.senderCity}, ${formData.senderData.senderRegion}, ${formData.senderData.senderCountry}`
              : `${formData.senderData.senderCity}, ${formData.senderData.senderRegion}, ${formData.senderData.senderCountry}`
          }
          initialArrivalAddress={
            formData.recipientData.recipientAddress
              ? `${formData.recipientData.recipientAddress}, ${formData.recipientData.recipientCity}, ${formData.recipientData.recipientRegion}, ${formData.recipientData.recipientCountry}`
              : `${formData.recipientData.recipientCity}, ${formData.recipientData.recipientRegion}, ${formData.recipientData.recipientCountry}`
          }
          initialDepartureCoords={
            formData.senderData.latitude && formData.senderData.longitude
              ? { lat: formData.senderData.latitude, lon: formData.senderData.longitude }
              : undefined
          }
          initialArrivalCoords={
            formData.recipientData.recipientLatitude && formData.recipientData.recipientLongitude
              ? { lat: formData.recipientData.recipientLatitude, lon: formData.recipientData.recipientLongitude }
              : undefined
          }
          transportMethod={formData.packageData.transportMethod.join(',')}
          onContinue={(routeData, travelPrice) => setFormData(prev => ({ ...prev, routeData, pricing: { ...prev.pricing, travelPrice }, currentStep: 5 }))}
          onBack={() => setFormData(prev => ({ ...prev, currentStep: 3 }))}
        />;
      case 5:
        return <SignatureStep
          onSubmit={(signatureUrl) => setFormData(prev => ({ ...prev, signatureData: { signatureUrl }, currentStep: 6 }))}
          onBack={() => setFormData(prev => ({ ...prev, currentStep: 4 }))}
        />;
      case 6:
        // Construction de l'objet final pour le composant de paiement
        // Conversion forcée et nettoyage des types
        const fullDataForPayment: any = {
          ...formData.senderData,
          senderFirstName: formData.senderData.senderFirstName,
          senderLastName: formData.senderData.senderLastName,
          recipientFirstName: formData.recipientData.recipientFirstName,
          recipientLastName: formData.recipientData.recipientLastName,
          recipientPhone: formData.recipientData.recipientPhone,
          recipientEmail: formData.recipientData.recipientEmail,
          recipientCountry: formData.recipientData.recipientCountry,
          recipientRegion: formData.recipientData.recipientRegion,
          recipientCity: formData.recipientData.recipientCity,
          recipientAddress: formData.recipientData.recipientAddress,
          ...formData.packageData,
          transportMethod: formData.packageData.transportMethod,
          // Gérer explicitement le type File/String de la photo
          photo: typeof formData.packageData.photo === 'string' ? formData.packageData.photo : null,
          ...formData.routeData,
          ...formData.signatureData,
          // Ne pas caster en Number() si ce sont des UUIDs (chaines)
          departurePointId: (formData.routeData.departurePointId) as any,
          arrivalPointId: (formData.routeData.arrivalPointId) as any,
          basePrice: formData.pricing.basePrice,
          travelPrice: formData.pricing.travelPrice,
        };
        return <PaymentStep
          allData={fullDataForPayment}
          onPaymentFinalized={(finalPricing) => {
            setFormData(prev => ({ ...prev, pricing: finalPricing, currentStep: 7 }));
            localStorage.removeItem(EXPEDITION_FORM_STORAGE_KEY);
          }}
          onBack={() => setFormData(prev => ({ ...prev, currentStep: 5 }))}
          currentUser={user}
        />;
      case 7:
        return (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="min-h-screen flex items-center justify-center bg-orange-50 dark:bg-gray-900 p-4"
          >
            <div className="max-w-md w-full text-center space-y-6">
              <div className="bg-white dark:bg-gray-800 rounded-3xl p-8 shadow-xl">
                <motion.div
                  animate={{ scale: [1, 1.1, 1], rotate: [0, 5, -5, 0] }}
                  transition={{ duration: 2, repeat: Infinity, ease: 'easeInOut' }}
                >
                  <CheckCircleIcon className="w-24 h-24 text-green-500 mx-auto drop-shadow-lg" />
                </motion.div>

                <h2 className="text-2xl font-bold text-gray-800 dark:text-gray-100 mt-4 mb-2">Expédition confirmée !</h2>
                <p className="text-gray-600 dark:text-gray-300 mb-6">Votre colis a été enregistré.</p>

                <div className="bg-orange-50 dark:bg-orange-900/30 rounded-2xl p-4 mb-6">
                  <p className="text-sm text-gray-600 dark:text-gray-400 mb-1">Numéro de suivi</p>
                  <p className="text-2xl font-bold text-orange-600 dark:text-orange-400 break-all">{trackingNumber}</p>
                  <button
                    onClick={() => {
                      navigator.clipboard.writeText(trackingNumber);
                    }}
                    className="mt-3 inline-flex items-center gap-2 px-4 py-2 bg-orange-100 dark:bg-orange-800/50 text-orange-700 dark:text-orange-300 rounded-lg text-sm font-medium hover:bg-orange-200 dark:hover:bg-orange-800 transition-colors"
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                      <rect x="9" y="9" width="13" height="13" rx="2" ry="2" />
                      <path d="M5 15H4a2 2 0 01-2-2V4a2 2 0 012-2h9a2 2 0 012 2v1" />
                    </svg>
                    Copier le numéro
                  </button>
                </div>

                {/* Bouton télécharger le bordereau */}
                <motion.button
                  onClick={generateBordereauPDF}
                  className="w-full flex items-center justify-center bg-orange-600 hover:bg-orange-700 text-white font-semibold py-3 px-6 rounded-xl transition-colors shadow-lg"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <PrinterIcon className="w-5 h-5 mr-2" />
                  Télécharger le Bordereau
                </motion.button>
              </div>

              {/* Bloc d'incitation à l'inscription (seulement si pas connecté) */}
              {!user && (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.5 }}
                  className="bg-white dark:bg-gray-800 rounded-3xl p-6 shadow-xl border-2 border-dashed border-orange-300 dark:border-orange-600"
                >
                  <div className="flex items-center justify-center gap-2 mb-3">
                    <StarIcon className="w-6 h-6 text-orange-400" />
                    <h3 className="text-xl font-bold text-gray-800 dark:text-gray-100">Devenez Client !</h3>
                  </div>
                  <p className="text-sm text-gray-600 dark:text-gray-300 mb-4">
                    Créez votre compte pour suivre vos colis, voir votre historique et bénéficier d'offres exclusives. Vos informations sont déjà prêtes !
                  </p>
                  <motion.button
                    onClick={handleCreateAccount}
                    className="w-full flex items-center justify-center bg-gradient-to-r from-green-500 to-emerald-500 text-white font-bold py-3 px-6 rounded-xl shadow-md transition-all"
                    whileHover={{ scale: 1.05, y: -2 }}
                    whileTap={{ scale: 0.98 }}
                  >
                    <UserPlusIcon className="w-5 h-5 mr-2" />
                    Créer mon compte en 1 clic
                  </motion.button>
                </motion.div>
              )}

              <button
                onClick={resetFormAndStartOver}
                className="text-gray-500 hover:text-orange-600 text-sm font-medium mt-4"
              >
                Effectuer une autre expédition
              </button>
            </div>
          </motion.div>
        );
      default:
        return null;
    }
  };

  if (!isMounted || isLoadingUser) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50 dark:bg-gray-900">
        <motion.div
          className="text-center"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5 }}
        >
          <motion.div
            animate={{ rotate: 360 }}
            transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
            className="w-12 h-12 border-3 border-orange-200 dark:border-orange-800 border-t-orange-500 dark:border-t-orange-400 rounded-full mx-auto mb-3"
          />
          <p className="text-orange-600 dark:text-orange-400 font-semibold">Chargement de votre session...</p>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-orange-50 dark:from-gray-900 dark:to-gray-800">
      <main className="container mx-auto px-4 py-4">
        <motion.div
          className="text-center mb-4"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <button
            onClick={() => router.push('/client')}
            className="mb-2 group flex items-center mx-auto text-orange-600 dark:text-orange-400 text-sm hover:text-orange-700 dark:hover:text-orange-300 transition-colors duration-200"
          >
            <ArrowUturnLeftIcon className="w-4 h-4 mr-1" /> Retour à l'accueil
          </button>
          <h1 className="text-2xl sm:text-3xl font-bold text-slate-800 dark:text-gray-100">Processus de Dépôt de Colis</h1>
          <p className="mt-1 text-sm text-slate-600 dark:text-gray-300 max-w-xl mx-auto">Suivez les étapes pour expédier votre colis en toute simplicité.</p>
        </motion.div>

        <div className="sticky top-0 z-40 bg-white/80 dark:bg-gray-900/80 backdrop-blur-sm py-2 -mx-4 px-4 mb-3 border-b border-orange-100/50 dark:border-orange-800/30">
          <ShippingSteps currentStep={formData.currentStep} />
        </div>

        <div className="bg-transparent rounded-xl p-4 md:p-1">
          <AnimatePresence mode="wait">
            <motion.div
              key={formData.currentStep}
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.25, ease: 'easeInOut' }}
            >
              {renderCurrentStep()}
            </motion.div>
          </AnimatePresence>
        </div>
      </main>
    </div>
  );
}
