import apiClient from '@/lib/axios';

const API_URL = '/api/announcements';

export interface AnnouncementResponseDTO {
    id: string;
    clientId: string;
    title: string;
    description: string;
    status: string;
    createdAt: string;
    updatedAt: string;
    recipientFirstName: string;
    recipientLastName: string;
    recipientEmail: string;
    recipientPhone: string;
    shipperFirstName: string;
    shipperLastName: string;
    shipperEmail: string;
    shipperPhone: string;
    amount: number;
    pickupAddress: {
        street: string;
        city: string;
        district: string;
        country: string;
        description: string;
        type: string;
        latitude?: number;
        longitude?: number;
    };
    deliveryAddress: {
        street: string;
        city: string;
        district: string;
        country: string;
        description: string;
        type: string;
        latitude?: number;
        longitude?: number;
    };
    packet: {
        width: number;
        length: number;
        fragile: boolean;
        description: string;
        photoPacket: string;
        isPerishable: boolean;
        thickness: number;
        designation: string;
    };
    distance?: number;
    duration?: number;
    // Assigned delivery person info (when status is ASSIGNED)
    assignedDeliveryPersonId?: string;
    assignedDeliveryPersonFirstName?: string;
    assignedDeliveryPersonLastName?: string;
    assignedDeliveryPersonEmail?: string;
    assignedDeliveryPersonPhone?: string;
}

export const getAnnouncementById = async (id: string): Promise<AnnouncementResponseDTO> => {
    try {
        const response = await apiClient.get(`${API_URL}/${id}`);
        return response.data;
    } catch (error: any) {
        console.error('Error fetching announcement by ID:', error.response?.data?.message || error.response?.data || error.message);
        throw error;
    }
};

export const getAnnouncementByClientId = async (clientId: string): Promise<AnnouncementResponseDTO[]> => {
    if (!clientId) {
        console.error('getAnnouncementByClientId: clientId is missing');
        return [];
    }
    try {
        const response = await apiClient.get(`${API_URL}/client/${clientId}`);
        return response.data;
    } catch (error: any) {
        console.error('Error fetching announcements by client ID:', error.response?.data?.message || error.response?.data || error.message);
        throw error;
    }
};

export const deleteAnnouncement = async (id: string): Promise<void> => {
    try {
        await apiClient.delete(`${API_URL}/${id}`);
    } catch (error: any) {
        console.error('Error deleting announcement:', error.response?.data || error.message);
        throw error;
    }
};


export interface AnnouncementCreationPayload {
    clientId: string;
    title: string;
    description?: string;
    recipientFirstName: string;
    recipientLastName: string;

    recipientEmail: string;
    recipientPhone: string;
    shipperFirstName: string;
    shipperLastName: string;
    shipperEmail: string;
    shipperPhone: string;
    amount: number;
    signatureUrl?: string | null;
    paymentMethod: string;
    transportMethod: string;
    distance?: number;
    duration?: number;
    autoPublish?: boolean;

    pickupAddress: {
        street: string;
        city: string;
        district: string;
        country: string;
        description?: string;
        type: string;
        latitude?: number;
        longitude?: number;
    };
    deliveryAddress: {
        street: string;
        city: string;
        district: string;
        country: string;
        description?: string;
        type: string;
        latitude?: number;
        longitude?: number;
    };
    packet: {
        weight?: number;
        width?: number;
        height?: number;
        length?: number;
        fragile: boolean;
        description?: string;
        photoPacket?: string;
        isPerishable: boolean;
        thickness?: number;
        designation: string;
    };
}

export const createAnnouncement = async (payload: AnnouncementCreationPayload): Promise<AnnouncementResponseDTO> => {
    try {
        const response = await apiClient.post(API_URL, payload);
        return response.data;
    } catch (error: any) {
        console.error('Error creating announcement:', error.response?.data?.message || error.response?.data || error.message);
        throw error;
    }
};

export const publishAnnouncement = async (id: string): Promise<AnnouncementResponseDTO> => {
    try {
        const response = await apiClient.patch(`${API_URL}/${id}/publish`);
        return response.data;
    } catch (error: any) {
        console.error('Error publishing announcement:', error.response?.data || error.message);
        throw error;
    }
};

export const updateAnnouncement = async (id: string, payload: Partial<AnnouncementCreationPayload>): Promise<AnnouncementResponseDTO> => {
    try {
        const response = await apiClient.put(`${API_URL}/${id}`, payload);
        return response.data;
    } catch (error: any) {
        console.error('Error updating announcement:', error.response?.data?.message || error.response?.data || error.message);
        throw error;
    }
};

export interface SubscriptionResponseDTO {
    subscriptionId: string;
    deliveryPersonId: string;
    firstName: string;
    lastName: string;
    email: string;
    phone: string;
    rating: number | null;
    status: string;
    createdAt: string;
}

export const getSubscriptions = async (announcementId: string): Promise<SubscriptionResponseDTO[]> => {
    try {
        const response = await apiClient.get(`${API_URL}/${announcementId}/subscriptions`);
        return response.data;
    } catch (error: any) {
        console.error('Error fetching subscriptions:', error.response?.data?.message || error.response?.data || error.message);
        throw error;
    }
};

export const assignDeliveryPerson = async (announcementId: string, deliveryPersonId: string): Promise<AnnouncementResponseDTO> => {
    try {
        const response = await apiClient.post(`${API_URL}/${announcementId}/assign`, { deliveryPersonId });
        return response.data;
    } catch (error: any) {
        console.error('Error assigning delivery person:', error.response?.data?.message || error.response?.data || error.message);
        throw error;
    }
};

export const getPublishedAnnouncements = async (): Promise<AnnouncementResponseDTO[]> => {
    try {
        const response = await apiClient.get(`${API_URL}`);
        return response.data;
    } catch (error: any) {
        console.error('Error fetching published announcements:', error.response?.data?.message || error.response?.data || error.message);
        throw error;
    }
};

export const getDeliveryPersonSubscriptions = async (deliveryPersonId: string): Promise<AnnouncementResponseDTO[]> => {
    try {
        const response = await apiClient.get(`${API_URL}/subscriptions/delivery-person/${deliveryPersonId}`);
        return response.data;
    } catch (error: any) {
        console.error('Error fetching delivery person subscriptions:', error.response?.data?.message || error.response?.data || error.message);
        throw error;
    }
};
